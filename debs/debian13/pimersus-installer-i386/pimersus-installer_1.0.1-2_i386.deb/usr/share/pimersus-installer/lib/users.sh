#!/usr/bin/env bash

# =================================================================
# PimersusOS - Creación y configuración de usuarios
# =================================================================

create_users(){

    dialog --infobox "$(t creating_user_msg)" 5 55 \
        <"$TTY" >"$TTY" 2>"$TTY"

    # =================================================================
    # VALIDAR TARGET
    # =================================================================
    _assert_target

    local DEFAULT_USER="pimersus"

    # =================================================================
    # DATOS DE USUARIO
    # =================================================================
    local USERNAME

    while true; do

        USERNAME=$(input "$(t user)" "$DEFAULT_USER")

        if [[ "$USERNAME" =~ ^[a-z_][a-z0-9_.-]*$ ]]; then
            break
        fi

        msg "$(t user_invalid)"
    done

    # =================================================================
    # PASSWORD USUARIO
    # =================================================================
    local PASS1
    local PASS2

    while true; do

        PASS1=$(password "$(t pass)")
        PASS2=$(password "$(t confirm)")

        if [[ -n "$PASS1" && "$PASS1" == "$PASS2" ]]; then
            break
        fi

        msg "$(t pass_mismatch_or_empty)"
    done

    # =================================================================
    # PASSWORD ROOT
    # =================================================================
    local ROOTPASS

    while true; do

        ROOTPASS=$(password "$(t root_pass)")

        [[ -n "$ROOTPASS" ]] && break

        msg "$(t pass_empty)"
    done

    # =================================================================
    # CREAR / RENOMBRAR USUARIO
    # =================================================================
    dialog --infobox "$(t processing_user)" 5 45 \
        <"$TTY" >"$TTY" 2>"$TTY"

    if chroot "$TARGET" id "$DEFAULT_USER" >/dev/null 2>&1; then

        # =============================================================
        # RENOMBRAR USUARIO LIVE
        # =============================================================
        if [[ "$USERNAME" != "$DEFAULT_USER" ]]; then

            echo "[info] Renombrando usuario '$DEFAULT_USER' -> '$USERNAME'"

            chroot "$TARGET" pkill -u "$DEFAULT_USER" 2>/dev/null || true

            chroot "$TARGET" usermod -l "$USERNAME" "$DEFAULT_USER" || {
                msg "Error crítico: usermod -l falló"
                return 1
            }

            chroot "$TARGET" usermod -d "/home/$USERNAME" -m "$USERNAME" || {
                msg "Error crítico: mover HOME falló"
                return 1
            }

            if chroot "$TARGET" getent group "$DEFAULT_USER" >/dev/null 2>&1; then
                chroot "$TARGET" groupmod -n "$USERNAME" "$DEFAULT_USER" || true
            fi

        else
            echo "[info] Reutilizando usuario '$DEFAULT_USER'"
        fi

    elif ! chroot "$TARGET" id "$USERNAME" >/dev/null 2>&1; then

        # =============================================================
        # CREAR NUEVO USUARIO
        # =============================================================
        chroot "$TARGET" useradd -m -s /bin/bash "$USERNAME" || {
            msg "Error: useradd falló"
            return 1
        }
    fi

    # =================================================================
    # PASSWORDS
    # =================================================================
    printf '%s:%s\n' "$USERNAME" "$PASS1" | \
        chroot "$TARGET" chpasswd || {

        msg "Error: no se pudo asignar contraseña al usuario"
        return 1
    }

    printf '%s:%s\n' "root" "$ROOTPASS" | \
        chroot "$TARGET" chpasswd || {

        msg "Error: no se pudo asignar contraseña root"
        return 1
    }

    # =================================================================
    # GRUPOS
    # =================================================================
    local EXTRA_GROUPS="sudo,audio,video,cdrom,plugdev,netdev,lpadmin,scanner"

    for grp in ${EXTRA_GROUPS//,/ }; do
        chroot "$TARGET" groupadd -r "$grp" 2>/dev/null || true
    done

    chroot "$TARGET" usermod -aG "$EXTRA_GROUPS" "$USERNAME" || {
        msg "Error: no se pudieron asignar grupos"
        return 1
    }

    # =================================================================
    # REPARAR HOME
    # =================================================================
    local PRIMARY_GROUP

    PRIMARY_GROUP=$(chroot "$TARGET" id -gn "$USERNAME" 2>/dev/null || echo "$USERNAME")

    chroot "$TARGET" chown -R "$USERNAME:$PRIMARY_GROUP" "/home/$USERNAME" \
        2>/dev/null || true

    dialog --infobox "$(t user_done)" 5 50 \
        <"$TTY" >"$TTY" 2>"$TTY"

    echo "[info] Usuario '$USERNAME' configurado correctamente"
}
