#!/usr/bin/env bash

# =================================================================
# PimersusOS - Utilidades del sistema (i386 / 32 bits)
# =================================================================

# =================================================================
# TTY GLOBAL
# =================================================================
TTY=/dev/tty

# Fallback para antiX Core / entornos sin TTY estándar
if [[ ! -w "$TTY" ]]; then
    TTY=$(tty 2>/dev/null) || TTY=/dev/console
fi

export TTY

# =================================================================
# VARIABLE GLOBAL DEL DESTINO
# =================================================================
TARGET="/target"

# =================================================================
# LOGGING
# =================================================================
init_log(){
    LOG="/var/log/pimersus-installer.log"

    exec > >(tee -a "$LOG") 2>&1

    echo "[info] === PimersusOS Installer iniciado: $(date) ==="
}

# =================================================================
# VALIDACIÓN TARGET
# =================================================================
_assert_target(){

    local t="${TARGET:-}"

    if [[ -z "$t" || "$t" == "/" || "$t" == "/." ]]; then
        echo "[FATAL] TARGET inválido: '$t'" >&2
        exit 99
    fi

    if ! mountpoint -q "$t" 2>/dev/null; then
        echo "[FATAL] TARGET '$t' no está montado" >&2
        exit 99
    fi
}

# =================================================================
# DETECTAR mkfs.fat / mkfs.vfat
# =================================================================
_detect_fatmkfs(){

    if command -v mkfs.fat &>/dev/null; then
        FATMKFS="mkfs.fat"

    elif command -v mkfs.vfat &>/dev/null; then
        FATMKFS="mkfs.vfat"

    else
        FATMKFS=""
    fi

    export FATMKFS
}

# =================================================================
# VALIDAR DEPENDENCIAS
# =================================================================
check_dependencies(){

    local missing=()

    local required_tools=(
        rsync
        dialog
        parted
        blkid
        chroot
        mount
        umount
        mkfs.ext4
    )

    for tool in "${required_tools[@]}"; do
        if ! command -v "$tool" &>/dev/null; then
            missing+=("$tool")
        fi
    done

    # Detectar mkfs FAT compatible
    _detect_fatmkfs

    if [[ -z "${FATMKFS:-}" ]]; then
        missing+=("mkfs.fat o mkfs.vfat (dosfstools)")
    fi

    # grub-install puede existir solo dentro del target
    if ! command -v grub-install &>/dev/null && \
       [[ ! -x "$TARGET/usr/sbin/grub-install" ]]; then
        missing+=("grub-install")
    fi

    # os-prober opcional
    if ! command -v os-prober &>/dev/null; then
        echo "[warn] os-prober no encontrado"
    fi

    if [[ ${#missing[@]} -gt 0 ]]; then

        local list
        list=$(printf '  • %s\n' "${missing[@]}")

        dialog --msgbox \
            "ERROR: Faltan dependencias requeridas:\n\n${list}\nInstálalas y vuelve a ejecutar el instalador." \
            $(( ${#missing[@]} + 10 )) 70 \
            <"$TTY" >"$TTY" 2>"$TTY"

        exit 1
    fi

    echo "[info] Todas las dependencias presentes"
}

# =================================================================
# DETECTAR UEFI
# =================================================================
check_uefi(){

    if [[ -d /sys/firmware/efi ]]; then

        echo "[info] Modo UEFI 32 bits detectado"

        dialog --yesno \
            "⚠ Modo UEFI detectado en sistema 32 bits.\nSe usará target i386-efi.\n\n¿Continuar?" \
            10 55 <"$TTY" >"$TTY" 2>"$TTY" || exit 1

    else
        echo "[info] Modo Legacy/BIOS detectado"
    fi
}

# =================================================================
# VALIDAR LIVE
# =================================================================
check_live(){

    if ! grep -qE "overlay|overlayfs|squashfs|live|aufs|casper|toram" /proc/1/mounts 2>/dev/null && \
       ! grep -qE "overlay|overlayfs|squashfs|live|aufs|casper|toram" /proc/mounts 2>/dev/null; then

        dialog --msgbox \
            "ERROR: Debes ejecutar el instalador desde un sistema live (USB/CD)." \
            8 60 <"$TTY" >"$TTY" 2>"$TTY"

        exit 1
    fi
}

# =================================================================
# DETECTAR OTROS SISTEMAS
# =================================================================
detect_systems(){

    if command -v os-prober &>/dev/null; then

        echo "[info] Detectando otros sistemas operativos (timeout 15s)..."

        local found
        found=$(timeout 15 os-prober 2>/dev/null || true)

        if [[ -n "$found" ]]; then

            dialog --msgbox \
                "Sistemas detectados:\n\n$found" \
                12 60 <"$TTY" >"$TTY" 2>"$TTY"
        fi
    fi
}

# =================================================================
# CLEANUP
# =================================================================
cleanup(){

    dialog --infobox \
        "$(t cleanup_start)" \
        5 50 <"$TTY" >"$TTY" 2>"$TTY"

    local mounts=(
        "$TARGET/dev/pts"
        "$TARGET/dev/shm"
        "$TARGET/dev"
        "$TARGET/run"
        "$TARGET/sys"
        "$TARGET/proc"
        "$TARGET/boot/efi"
        "$TARGET"
    )

    for mp in "${mounts[@]}"; do

        if mountpoint -q "$mp" 2>/dev/null; then

            umount "$mp" 2>/dev/null || \
            umount -l "$mp" 2>/dev/null || \
            echo "[warn] No se pudo desmontar $mp"
        fi
    done

    # Fallback final por si quedó algo montado
    umount -R "$TARGET" 2>/dev/null || true

    dialog --infobox \
        "$(t cleanup_done)" \
        5 45 <"$TTY" >"$TTY" 2>"$TTY"
}

# =================================================================
# FINALIZAR
# =================================================================
finish(){

    local choice

    choice=$(dialog --stdout \
        --menu "$(t done)\n\n$(t finish_question)" \
        12 50 2 \
        "reboot"   "$(t restart_now)" \
        "poweroff" "$(t poweroff_now)" \
        <"$TTY" >"$TTY" 2>"$TTY") || choice="reboot"

    sync
    sleep 2

    case "$choice" in
        poweroff) poweroff ;;
        *) reboot ;;
    esac
}
