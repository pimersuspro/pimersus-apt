#!/usr/bin/env bash

# =================================================================
# PimersusOS - Configuración del sistema instalado
# =================================================================

configure_system(){

    # =================================================================
    # VALIDAR TARGET
    # =================================================================
    _assert_target

    # =================================================================
    # HOSTNAME
    # =================================================================
    HOSTNAME=$(input "$(t host)" "pimersus")

    [[ -z "$HOSTNAME" ]] && HOSTNAME="pimersus"

    HOSTNAME=$(
        echo "$HOSTNAME" |
        tr '[:upper:]' '[:lower:]' |
        sed 's/[^a-z0-9-]/-/g; s/-\+/-/g; s/^-//; s/-$//'
    )

    [[ -z "$HOSTNAME" ]] && HOSTNAME="pimersus"

    echo "$HOSTNAME" > "$TARGET/etc/hostname"

    cat > "$TARGET/etc/hosts" <<EOF
127.0.0.1   localhost
127.0.1.1   $HOSTNAME
::1         localhost ip6-localhost ip6-loopback
EOF

    # =================================================================
    # LOCALES
    # =================================================================
    mkdir -p "$TARGET/etc/default"

    echo "en_US.UTF-8 UTF-8" > "$TARGET/etc/locale.gen"

    local FINAL_LANG="en_US.UTF-8"
    local KMAP="us"

    case "${LANG_CHOICE:-en}" in
        es)
            echo "es_ES.UTF-8 UTF-8" >> "$TARGET/etc/locale.gen"
            FINAL_LANG="es_ES.UTF-8"
            KMAP="es"
            ;;
        fr)
            echo "fr_FR.UTF-8 UTF-8" >> "$TARGET/etc/locale.gen"
            FINAL_LANG="fr_FR.UTF-8"
            KMAP="fr"
            ;;
        de)
            echo "de_DE.UTF-8 UTF-8" >> "$TARGET/etc/locale.gen"
            FINAL_LANG="de_DE.UTF-8"
            KMAP="de"
            ;;
    esac

    # Generar locales con LC_ALL=C para evitar errores de entorno
    chroot "$TARGET" /bin/bash -c "export LC_ALL=C; locale-gen" || {
        msg "Error: locale-gen falló"
        exit 1
    }

    echo "LANG=$FINAL_LANG" > "$TARGET/etc/default/locale"

    # =================================================================
    # TECLADO
    # =================================================================
    cat > "$TARGET/etc/default/keyboard" <<EOF
XKBMODEL="pc105"
XKBLAYOUT="$KMAP"
XKBVARIANT=""
XKBOPTIONS=""
BACKSPACE="guess"
EOF

    # =================================================================
    # DESACTIVAR MULTIARCH (Para optimizar 32 bits)
    # =================================================================
    rm -f "$TARGET/etc/dpkg/dpkg.cfg.d/multiarch" 2>/dev/null || true

    # =================================================================
    # RED
    # =================================================================
    if chroot "$TARGET" command -v NetworkManager >/dev/null 2>&1 || \
       [[ -f "$TARGET/etc/NetworkManager/NetworkManager.conf" ]]; then
        echo "[info] NetworkManager detectado"
    else
        mkdir -p "$TARGET/etc/network"
        cat > "$TARGET/etc/network/interfaces" <<EOF
# PimersusOS network config
auto lo
iface lo inet loopback

allow-hotplug eth0
iface eth0 inet dhcp

allow-hotplug enp0s3
iface enp0s3 inet dhcp

allow-hotplug wlan0
iface wlan0 inet dhcp
EOF
    fi

    # =================================================================
    # TIMEZONE
    # =================================================================
    _select_timezone

    # =================================================================
    # SYSCTL (Optimizaciones hardware antiguo)
    # =================================================================
    mkdir -p "$TARGET/etc/sysctl.d"
    cat > "$TARGET/etc/sysctl.d/99-pimersus.conf" <<EOF
# PimersusOS optimizaciones hardware viejo
vm.swappiness=10
vm.vfs_cache_pressure=50
vm.dirty_ratio=10
vm.dirty_background_ratio=5
EOF

    # =================================================================
    # SWAPFILE (Lógica inteligente basada en RAM)
    # =================================================================
    if ! grep -q "/swapfile" "$TARGET/etc/fstab" && [[ ! -f "$TARGET/swapfile" ]]; then

        local RAM_MB
        local SWAP_MB
        RAM_MB=$(awk '/MemTotal/ {print int($2/1024)}' /proc/meminfo)

        if (( RAM_MB < 512 )); then
            SWAP_MB=2048
        elif (( RAM_MB < 1024 )); then
            SWAP_MB=1536
        elif (( RAM_MB < 2048 )); then
            SWAP_MB=1024
        else
            SWAP_MB=512
        fi

        echo "[info] Creando swapfile: ${SWAP_MB}MB (RAM: ${RAM_MB}MB)"

        dd if=/dev/zero of="$TARGET/swapfile" bs=1M count="$SWAP_MB" status=none || {
            msg "Error: no se pudo crear swapfile"
            exit 1
        }

        chmod 600 "$TARGET/swapfile"
        chroot "$TARGET" mkswap /swapfile >/dev/null 2>&1
        echo "/swapfile none swap sw 0 0" >> "$TARGET/etc/fstab"
    fi
    
    # =================================================================
    # SINCRONIZAR RELOJ HARDWARE
    # =================================================================
    if command -v hwclock >/dev/null 2>&1; then
        hwclock --systohc 2>/dev/null || true
    fi

    sync
    echo "[info] Configuración del sistema completada"
}

# =================================================================
# SELECCIÓN TIMEZONE
# =================================================================
_select_timezone(){
    local REGION
    REGION=$(dialog --stdout \
        --menu "$(t tz_region)" 18 60 10 \
        "America"    "$(t tz_america)" \
        "Europe"     "$(t tz_europe)" \
        "Asia"       "$(t tz_asia)" \
        "Africa"     "$(t tz_africa)" \
        "Pacific"    "$(t tz_pacific)" \
        "Atlantic"   "$(t tz_atlantic)" \
        "Indian"     "$(t tz_indian)" \
        "Antarctica" "$(t tz_antarctica)" \
        "UTC"        "UTC / GMT" \
        <"$TTY" >"$TTY" 2>"$TTY") || REGION="UTC"

    [[ -z "$REGION" ]] && REGION="UTC"

    if [[ "$REGION" == "UTC" ]]; then
        _apply_timezone "UTC"
        return
    fi

    local TZ_LIST=()
    while IFS= read -r tz; do
        local city="${tz#*/}"
        TZ_LIST+=("$tz" "$city")
    done < <(
        find /usr/share/zoneinfo/"$REGION" -maxdepth 1 \
            \( -type f -o -type l \) 2>/dev/null |
        sed "s|/usr/share/zoneinfo/||" |
        sort
    )

    if [[ ${#TZ_LIST[@]} -eq 0 ]]; then
        _apply_timezone "UTC"
        return
    fi

    local TZ_CHOICE
    TZ_CHOICE=$(dialog --stdout \
        --menu "$(t tz_zone) ($REGION)" 20 60 12 \
        "${TZ_LIST[@]}" \
        <"$TTY" >"$TTY" 2>"$TTY") || TZ_CHOICE="UTC"

    [[ -z "$TZ_CHOICE" ]] && TZ_CHOICE="UTC"
    _apply_timezone "$TZ_CHOICE"
}

# =================================================================
# APLICAR TIMEZONE
# =================================================================
_apply_timezone(){
    local TZ="$1"
    if [[ ! -f "/usr/share/zoneinfo/$TZ" ]]; then
        TZ="UTC"
    fi

    chroot "$TARGET" ln -sf "/usr/share/zoneinfo/$TZ" /etc/localtime 2>/dev/null || true
    echo "$TZ" > "$TARGET/etc/timezone"
    echo "[info] Timezone configurada: $TZ"
}