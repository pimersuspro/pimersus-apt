#!/usr/bin/env bash

# =================================================================
# PimersusOS - Gestión de discos (i386 / 32 bits)
# Hardware objetivo: BIOS Legacy y UEFI i386-efi
# =================================================================

select_mode(){

    MODE=$(menu "$(t mode)" \
        "auto"   "$(t auto)" \
        "manual" "$(t manual)")

    [[ -z "$MODE" ]] && exit 1

    export MODE
}

setup_disks(){

    case "$MODE" in
        auto)   auto_partition ;;
        manual) manual_partition ;;
        *)      exit 1 ;;
    esac
}

# =================================================================
# Obtener discos disponibles
# =================================================================
get_available_disks(){

    lsblk -dn -o NAME,SIZE,TYPE | while read -r name size type; do

        [[ -z "$name" ]] && continue
        [[ "$type" != "disk" ]] && continue

        local ro
        ro=$(cat "/sys/block/$name/ro" 2>/dev/null || echo "0")

        [[ "$ro" == "1" ]] && continue

        echo "/dev/$name|$size"
    done
}

# =================================================================
# Esperar a que aparezca un device node
# =================================================================
_wait_for_block(){

    local dev="$1"
    local retries=10

    while [[ ! -b "$dev" ]] && (( retries-- > 0 )); do
        sleep 1
        udevadm settle --timeout=3 2>/dev/null || true
    done

    [[ -b "$dev" ]]
}

# =================================================================
# Validar tamaño mínimo EFI
# =================================================================
_validate_efi_size(){

    local efi_dev="$1"

    local size_bytes
    size_bytes=$(blockdev --getsize64 "$efi_dev" 2>/dev/null || echo 0)

    local min_bytes=$((100 * 1024 * 1024))
    local rec_bytes=$((512 * 1024 * 1024))

    if [[ "$size_bytes" -lt "$min_bytes" ]]; then

        local size_mb=$(( size_bytes / 1024 / 1024 ))

        dialog --msgbox \
            "ERROR: La partición EFI ($efi_dev) tiene solo ${size_mb}MB.\n\nEl mínimo absoluto es 100MB.\nGRUB no podrá instalarse correctamente." \
            11 65 <"$TTY" >"$TTY" 2>"$TTY"

        return 1
    fi

    if [[ "$size_bytes" -lt "$rec_bytes" ]]; then

        local size_mb=$(( size_bytes / 1024 / 1024 ))

        dialog --yesno \
            "⚠ Advertencia: La partición EFI ($efi_dev) tiene ${size_mb}MB.\n\nSe recomienda al menos 512MB.\n\n¿Continuar?" \
            11 65 <"$TTY" >"$TTY" 2>"$TTY" || return 1
    fi

    return 0
}

# =================================================================
# Limpieza profunda robusta
# =================================================================
_wipe_disk(){

    local disk="$1"

    if command -v blkdiscard &>/dev/null; then

        echo "[info] Intentando blkdiscard en $disk..."

        if timeout 20 blkdiscard "$disk" 2>/dev/null; then
            echo "[info] blkdiscard completado"
            return 0
        fi

        echo "[warn] blkdiscard no soportado, usando dd"
    fi

    echo "[info] Ejecutando dd wipe..."

    if ! timeout 30 dd if=/dev/zero of="$disk" bs=1M count=10 conv=fdatasync 2>/dev/null; then
		echo "[warn] dd wipe falló o fue interrumpido"
	fi

    return 0
}

# =================================================================
# Formateo robusto
# =================================================================
safe_format(){

    local type="$1"
    local dev="$2"
    local label="$3"

    sync
    sleep 1

    if [[ "$type" == "ext4" ]]; then

        mkfs.ext4 -F -L "$label" "$dev" || {
            echo "[error] mkfs.ext4 falló en $dev"
            return 1
        }

    else

        "${FATMKFS:-mkfs.fat}" -F32 -n "$label" "$dev" || {
            echo "[error] ${FATMKFS:-mkfs.fat} falló en $dev"
            return 1
        }
    fi

    udevadm settle --timeout=10 2>/dev/null || sleep 2

    sync
}

# =================================================================
# MODO MANUAL
# =================================================================
manual_partition(){

    local OPTIONS=()

    while IFS='|' read -r dev label; do
        OPTIONS+=("$dev" "$label")
    done < <(get_available_disks)

    if [[ ${#OPTIONS[@]} -eq 0 ]]; then
		msg "$(t no_disks)"
		exit 1
	fi

    DISK=$(menu "$(t disk)" "${OPTIONS[@]}")

    [[ -z "$DISK" ]] && exit 1

    export DISK

    dialog --msgbox \
        "Se abrirá cfdisk. Crea tus particiones y anota los nombres.\n\nBIOS: ROOT\nUEFI: EFI + ROOT" \
        10 65 <"$TTY" >"$TTY" 2>"$TTY"

    clear
    reset

    cfdisk "$DISK"

    clear

    ROOT=$(input "Introduce la partición ROOT:" "")

    [[ -z "$ROOT" ]] && exit 1
    [[ -b "$ROOT" ]] || {
        msg "Partición ROOT inválida"
        exit 1
    }

    export ROOT

    dialog --yesno "$(t format_root) ($ROOT)" 7 55 \
        <"$TTY" >"$TTY" 2>"$TTY" && \
        safe_format "ext4" "$ROOT" "PimersusRoot"

    if [[ -d /sys/firmware/efi ]]; then

        EFI=$(input "Introduce la partición EFI:" "")

        [[ -z "$EFI" ]] && exit 1

        [[ -b "$EFI" ]] || {
            msg "Partición EFI inválida"
            exit 1
        }

        if [[ "$ROOT" == "$EFI" ]]; then
            msg "ROOT y EFI no pueden ser la misma partición"
            exit 1
        fi

        _validate_efi_size "$EFI" || exit 1

        export EFI

        dialog --yesno "$(t format_efi) ($EFI)" 7 55 \
            <"$TTY" >"$TTY" 2>"$TTY" && \
            safe_format "fat" "$EFI" "EFI"

    else
        EFI=""
        export EFI
    fi
}

# =================================================================
# MODO AUTOMÁTICO
# =================================================================
auto_partition(){

    local OPTIONS=()

    while IFS='|' read -r dev label; do
        OPTIONS+=("$dev" "$label")
    done < <(get_available_disks)

    if [[ ${#OPTIONS[@]} -eq 0 ]]; then
		msg "$(t no_disks)"
		exit 1
	fi

    DISK=$(menu "$(t disk)" "${OPTIONS[@]}")

    [[ -z "$DISK" ]] && exit 1

    export DISK

    if lsblk -no MOUNTPOINT "$DISK" 2>/dev/null | grep -q '/'; then
        msg "$(t disk_busy)"
        exit 1
    fi

    dialog --yesno "$(t warn) $DISK ?" 10 50 \
        <"$TTY" >"$TTY" 2>"$TTY" || exit 1

    dialog --yesno "$(t warn2)\n\n$DISK" 10 60 \
        <"$TTY" >"$TTY" 2>"$TTY" || exit 1

    dialog --infobox "$(t part)" 5 40 \
        <"$TTY" >"$TTY" 2>"$TTY"

    # Limpieza profunda
    wipefs -af "$DISK" >/dev/null 2>&1 || true
    sgdisk --zap-all "$DISK" >/dev/null 2>&1 || true
    _wipe_disk "$DISK"

    local P=""

    case "$DISK" in
        *nvme*|*mmcblk*|*loop*)
            P="p"
            ;;
    esac

    if [[ -d /sys/firmware/efi ]]; then

        parted -s "$DISK" mklabel gpt
        parted -s "$DISK" mkpart ESP fat32 1MiB 513MiB
        parted -s "$DISK" set 1 esp on
        parted -s "$DISK" mkpart primary ext4 513MiB 100%

        sync
        partprobe "$DISK" || true
        udevadm settle --timeout=10 || true
        sleep 2

        EFI="${DISK}${P}1"
        ROOT="${DISK}${P}2"

        _wait_for_block "$EFI" || {
            msg "$(t part_fail)"
            exit 1
        }

        _wait_for_block "$ROOT" || {
            msg "$(t part_fail)"
            exit 1
        }

        _validate_efi_size "$EFI" || exit 1

        safe_format "fat" "$EFI" "EFI"
        safe_format "ext4" "$ROOT" "PimersusRoot"

    else

        parted -s "$DISK" mklabel msdos
        parted -s "$DISK" mkpart primary ext4 1MiB 100%
        parted -s "$DISK" set 1 boot on

        sync
        partprobe "$DISK" || true
        udevadm settle --timeout=10 || true
        sleep 2

        EFI=""
        ROOT="${DISK}${P}1"

        _wait_for_block "$ROOT" || {
            msg "$(t part_fail)"
            exit 1
        }

        safe_format "ext4" "$ROOT" "PimersusRoot"
    fi

    export EFI ROOT

    sync
}
