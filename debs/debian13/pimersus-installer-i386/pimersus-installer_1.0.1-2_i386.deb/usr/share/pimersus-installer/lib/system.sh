#!/usr/bin/env bash

# =================================================================
# PimersusOS - Montaje del sistema destino (i386 / 32 bits)
# TARGET se define en utils.sh
# =================================================================

mount_target(){

    [[ -z "${ROOT:-}"   ]] && {
        msg "Error: ROOT no definido"
        exit 1
    }

    [[ -z "${TARGET:-}" ]] && {
        msg "Error: TARGET no definido"
        exit 1
    }

    [[ "$TARGET" == "/" || "$TARGET" == "/." ]] && {
        msg "Error crítico: TARGET inválido"
        exit 1
    }

    [[ -b "$ROOT" ]] || {
        msg "Error: dispositivo ROOT inválido"
        exit 1
    }

    # =========================
    # LIMPIAR MONTAJES PREVIOS
    # =========================
    if mountpoint -q "$TARGET" 2>/dev/null; then
        echo "[info] Desmontando mounts previos en $TARGET"
        umount -R "$TARGET" 2>/dev/null || \
        umount -l "$TARGET" 2>/dev/null || true
    fi

    mkdir -p "$TARGET"

    # =========================
    # MONTAR ROOT
    # =========================
    mount "$ROOT" "$TARGET" || {
        msg "Error: No se pudo montar ROOT en $TARGET"
        exit 1
    }

    # Validar mount real
    mountpoint -q "$TARGET" || {
        msg "Error: ROOT no quedó montado correctamente"
        exit 1
    }

    # =========================
    # EFI (solo UEFI 32 bits)
    # =========================
    if [[ -d /sys/firmware/efi && -n "${EFI:-}" ]]; then

        [[ -b "$EFI" ]] || {
            msg "Error: dispositivo EFI inválido"
            exit 1
        }

        mkdir -p "$TARGET/boot/efi"

        mount "$EFI" "$TARGET/boot/efi" || {
            msg "Error: No se pudo montar partición EFI"
            exit 1
        }

        mountpoint -q "$TARGET/boot/efi" || {
            msg "Error: EFI no quedó montada correctamente"
            exit 1
        }
    fi

    # =========================
    # BIND MOUNTS PARA CHROOT
    # =========================
    local bind_mounts=(
        dev
        dev/shm
        proc
        sys
        run
    )

    for i in "${bind_mounts[@]}"; do

        mkdir -p "$TARGET/$i"

        if mountpoint -q "$TARGET/$i" 2>/dev/null; then
            echo "[info] $TARGET/$i ya está montado"
            continue
        fi

        mount --bind "/$i" "$TARGET/$i" || {
            msg "Error: Falló bind mount de /$i"
            exit 1
        }

        # Validar bind mount
        mountpoint -q "$TARGET/$i" || {
            msg "Error: Bind mount incompleto en $TARGET/$i"
            exit 1
        }
    done

    # =========================
    # DEVPTS
    # =========================
    mkdir -p "$TARGET/dev/pts"

    if ! mountpoint -q "$TARGET/dev/pts" 2>/dev/null; then

        mount --bind /dev/pts "$TARGET/dev/pts" || {
            msg "Error: Falló bind mount de /dev/pts"
            exit 1
        }

        mountpoint -q "$TARGET/dev/pts" || {
            msg "Error: /dev/pts no quedó montado"
            exit 1
        }
    fi

    # =========================
    # VALIDACIÓN FINAL
    # =========================
    _assert_target

    sync

    echo "[info] Sistema destino montado correctamente en $TARGET"
}
