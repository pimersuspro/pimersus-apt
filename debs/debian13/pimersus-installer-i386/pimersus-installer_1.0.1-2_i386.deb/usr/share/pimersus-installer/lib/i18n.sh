#!/usr/bin/env bash

# =================================================================
# PimersusOS - Sistema de Internacionalización (i18n)
# =================================================================

select_language(){

    LANG_CHOICE=$(dialog --stdout \
        --menu "Select Language / Seleccione Idioma" 12 50 4 \
        "en" "English" \
        "es" "Español" \
        "fr" "Français" \
        "de" "Deutsch" \
        <"$TTY" >"$TTY" 2>"$TTY")

    [[ -z "$LANG_CHOICE" ]] && LANG_CHOICE="en"

    export LANG_CHOICE
}

t(){

    case "$LANG_CHOICE:$1" in

    # =============================================================
    # ESPAÑOL
    # =============================================================

        es:mode)                  echo "Modo de instalación" ;;
        es:auto)                  echo "Borrar disco (automático)" ;;
        es:manual)                echo "Manual (avanzado)" ;;
        es:disk)                  echo "Selecciona el disco de destino" ;;

        es:warn)                  echo "¡ADVERTENCIA! Se borrará TODO en" ;;
        es:warn2)                 echo "⚠ ESTO BORRARÁ TODOS LOS DATOS ⚠" ;;

        es:part)                  echo "Limpiando y formateando disco..." ;;
        es:preparing_copy)        echo "Preparando la instalación..." ;;
        es:install_counting)      echo "Calculando archivos a copiar..." ;;
        es:install)               echo "Instalando PimersusOS (32 bits)..." ;;
        es:done)                  echo "¡Instalación completada con éxito!" ;;

        es:finish_question)       echo "¿Qué deseas hacer ahora?" ;;

        es:user)                  echo "Nombre de usuario" ;;
        es:pass)                  echo "Contraseña" ;;
        es:confirm)               echo "Confirmar contraseña" ;;
        es:root_pass)             echo "Contraseña de Root (Administrador)" ;;
        es:host)                  echo "Nombre del equipo (Hostname)" ;;

        es:user_exists)           echo "Error: El usuario ya existe en el sistema" ;;
        es:user_invalid)          echo "Nombre inválido. Use letras minúsculas, números y guiones." ;;

        es:pass_empty)            echo "Error: La contraseña no puede estar vacía" ;;
        es:pass_mismatch)         echo "Error: Las contraseñas no coinciden" ;;
        es:pass_mismatch_or_empty) echo "Error: Contraseñas vacías o no coinciden" ;;

        es:creating_user_msg)     echo "Configurando cuentas de usuario..." ;;
        es:create_user)           echo "Creando usuario..." ;;
        es:set_user_pass)         echo "Configurando contraseña del usuario..." ;;
        es:set_root_pass)         echo "Configurando contraseña root..." ;;
        es:add_sudo)              echo "Agregando usuario al grupo sudo..." ;;
        es:processing_user)       echo "Procesando usuario..." ;;
        es:user_done)             echo "Usuarios configurados correctamente." ;;

        es:no_disks)              echo "No se encontraron discos disponibles." ;;
        es:disk_busy)             echo "Error: El disco está en uso o montado." ;;
        es:part_fail)             echo "Error: Falló la creación de particiones." ;;

        es:format_efi)            echo "¿Formatear la partición EFI como FAT32?" ;;
        es:format_root)           echo "¿Formatear la partición ROOT como ext4?" ;;

        es:detect_systems)        echo "Configurando detección de sistemas..." ;;
        es:grub_step)             echo "Configurando el arranque (GRUB i386)..." ;;
        es:install_grub_uefi)     echo "Instalando GRUB i386-efi (UEFI 32 bits)..." ;;
        es:install_grub_legacy)   echo "Instalando GRUB i386-pc (BIOS Legacy)..." ;;
        es:update_grub)           echo "Generando configuración GRUB..." ;;
        es:efi_fallback)          echo "Configurando fallback EFI 32 bits (BOOTIA32.EFI)..." ;;
        es:removable_mode)        echo "Instalando modo removible i386-efi..." ;;
        es:grub_done)             echo "GRUB instalado correctamente." ;;

        es:cleanup_start)         echo "Desmontando sistemas de archivos..." ;;
        es:cleanup_done)          echo "Limpieza final completada." ;;

        es:tz_region)             echo "Selecciona una región horaria" ;;
        es:tz_zone)               echo "Selecciona una zona horaria" ;;
        es:tz_america)            echo "América" ;;
        es:tz_europe)             echo "Europa" ;;
        es:tz_asia)               echo "Asia" ;;
        es:tz_africa)             echo "África" ;;
        es:tz_pacific)            echo "Pacífico" ;;
        es:tz_atlantic)           echo "Atlántico" ;;
        es:tz_indian)             echo "Océano Índico" ;;
        es:tz_antarctica)         echo "Antártida" ;;

        es:restart_now)          echo "Reiniciar ahora" ;;
        es:poweroff_now)         echo "Apagar equipo" ;;


    # =============================================================
    # ENGLISH
    # =============================================================

        en:mode)                  echo "Installation mode" ;;
        en:auto)                  echo "Erase disk (automatic)" ;;
        en:manual)                echo "Manual (advanced)" ;;
        en:disk)                  echo "Select target disk" ;;

        en:warn)                  echo "WARNING! ALL data will be erased on" ;;
        en:warn2)                 echo "⚠ THIS WILL ERASE ALL DATA ⚠" ;;

        en:part)                  echo "Partitioning and formatting..." ;;
        en:preparing_copy)        echo "Preparing installation..." ;;
        en:install_counting)      echo "Calculating files to copy..." ;;
        en:install)               echo "Installing PimersusOS (32-bit)..." ;;
        en:done)                  echo "Installation completed successfully!" ;;

        en:finish_question)       echo "What do you want to do now?" ;;

        en:user)                  echo "Username" ;;
        en:pass)                  echo "Password" ;;
        en:confirm)               echo "Confirm Password" ;;
        en:root_pass)             echo "Root Password" ;;
        en:host)                  echo "Hostname" ;;

        en:user_exists)           echo "Error: User already exists in the system" ;;
        en:user_invalid)          echo "Invalid username. Use lowercase letters, numbers and hyphens." ;;

        en:pass_empty)            echo "Error: Password cannot be empty" ;;
        en:pass_mismatch)         echo "Error: Passwords do not match" ;;
        en:pass_mismatch_or_empty) echo "Error: Passwords are empty or do not match" ;;

        en:creating_user_msg)     echo "Configuring user accounts..." ;;
        en:create_user)           echo "Creating user..." ;;
        en:set_user_pass)         echo "Setting user password..." ;;
        en:set_root_pass)         echo "Setting root password..." ;;
        en:add_sudo)              echo "Adding user to sudo group..." ;;
        en:processing_user)       echo "Processing user..." ;;
        en:user_done)             echo "Users configured successfully." ;;

        en:no_disks)              echo "No available disks found." ;;
        en:disk_busy)             echo "Error: Disk is currently mounted or in use." ;;
        en:part_fail)             echo "Error: Partition creation failed." ;;

        en:format_efi)            echo "Format EFI partition as FAT32?" ;;
        en:format_root)           echo "Format ROOT partition as ext4?" ;;

        en:detect_systems)        echo "Configuring system detection..." ;;
        en:grub_step)             echo "Installing GRUB bootloader (i386)..." ;;
        en:install_grub_uefi)     echo "Installing GRUB i386-efi (UEFI 32-bit)..." ;;
        en:install_grub_legacy)   echo "Installing GRUB i386-pc (BIOS Legacy)..." ;;
        en:update_grub)           echo "Generating GRUB configuration..." ;;
        en:efi_fallback)          echo "Configuring EFI fallback (BOOTIA32.EFI)..." ;;
        en:removable_mode)        echo "Installing removable mode i386-efi..." ;;
        en:grub_done)             echo "GRUB installed successfully." ;;

        en:cleanup_start)         echo "Unmounting filesystems..." ;;
        en:cleanup_done)          echo "Final cleanup completed." ;;

        en:tz_region)             echo "Select timezone region" ;;
        en:tz_zone)               echo "Select timezone" ;;
        en:tz_america)            echo "America" ;;
        en:tz_europe)             echo "Europe" ;;
        en:tz_asia)               echo "Asia" ;;
        en:tz_africa)             echo "Africa" ;;
        en:tz_pacific)            echo "Pacific" ;;
        en:tz_atlantic)           echo "Atlantic" ;;
        en:tz_indian)             echo "Indian Ocean" ;;
        en:tz_antarctica)         echo "Antarctica" ;;

        en:restart_now)          echo "Restart now" ;;
        en:poweroff_now)         echo "Turn off the equipment" ;;


    # =============================================================
    # FRANÇAIS
    # =============================================================

        fr:mode)                  echo "Mode d'installation" ;;
        fr:auto)                  echo "Effacer le disque (automatique)" ;;
        fr:manual)                echo "Manuel (avancé)" ;;
        fr:disk)                  echo "Sélectionnez le disque cible" ;;

        fr:warn)                  echo "ATTENTION ! Toutes les données seront effacées sur" ;;
        fr:warn2)                 echo "⚠ TOUTES LES DONNÉES SERONT EFFACÉES ⚠" ;;

        fr:part)                  echo "Partitionnement et formatage..." ;;
        fr:preparing_copy)        echo "Préparation de l'installation..." ;;
        fr:install_counting)      echo "Calcul des fichiers à copier..." ;;
        fr:install)               echo "Installation de PimersusOS (32 bits)..." ;;
        fr:done)                  echo "Installation terminée avec succès !" ;;

        fr:finish_question)       echo "Que voulez-vous faire maintenant ?" ;;

        fr:user)                  echo "Nom d'utilisateur" ;;
        fr:pass)                  echo "Mot de passe" ;;
        fr:confirm)               echo "Confirmer le mot de passe" ;;
        fr:root_pass)             echo "Mot de passe Root" ;;
        fr:host)                  echo "Nom de la machine (Hostname)" ;;

        fr:user_exists)           echo "Erreur : L'utilisateur existe déjà" ;;
        fr:user_invalid)          echo "Nom invalide. Utilisez minuscules, chiffres et tirets." ;;

        fr:pass_empty)            echo "Erreur : Le mot de passe ne peut pas être vide" ;;
        fr:pass_mismatch)         echo "Erreur : Les mots de passe ne correspondent pas" ;;
        fr:pass_mismatch_or_empty) echo "Erreur : mots de passe vides ou différents" ;;

        fr:creating_user_msg)     echo "Configuration des comptes utilisateurs..." ;;
        fr:create_user)           echo "Création de l'utilisateur..." ;;
        fr:set_user_pass)         echo "Configuration du mot de passe utilisateur..." ;;
        fr:set_root_pass)         echo "Configuration du mot de passe root..." ;;
        fr:add_sudo)              echo "Ajout de l'utilisateur au groupe sudo..." ;;
        fr:processing_user)       echo "Traitement de l'utilisateur..." ;;
        fr:user_done)             echo "Utilisateurs configurés avec succès." ;;

        fr:no_disks)              echo "Aucun disque disponible trouvé." ;;
        fr:disk_busy)             echo "Erreur : Le disque est monté ou en cours d'utilisation." ;;
        fr:part_fail)             echo "Erreur : La création des partitions a échoué." ;;

        fr:format_efi)            echo "Formater la partition EFI en FAT32 ?" ;;
        fr:format_root)           echo "Formater la partition ROOT en ext4 ?" ;;

        fr:detect_systems)        echo "Configuration de la détection des systèmes..." ;;
        fr:grub_step)             echo "Installation de GRUB i386..." ;;
        fr:install_grub_uefi)     echo "Installation de GRUB i386-efi (UEFI 32 bits)..." ;;
        fr:install_grub_legacy)   echo "Installation de GRUB i386-pc (BIOS Legacy)..." ;;
        fr:update_grub)           echo "Génération de la configuration GRUB..." ;;
        fr:efi_fallback)          echo "Configuration du fallback EFI (BOOTIA32.EFI)..." ;;
        fr:removable_mode)        echo "Installation du mode amovible i386-efi..." ;;
        fr:grub_done)             echo "GRUB installé avec succès." ;;

        fr:cleanup_start)         echo "Démontage des systèmes de fichiers..." ;;
        fr:cleanup_done)          echo "Nettoyage final terminé." ;;

        fr:tz_region)             echo "Sélectionnez une région horaire" ;;
        fr:tz_zone)               echo "Sélectionnez un fuseau horaire" ;;
        fr:tz_america)            echo "Amérique" ;;
        fr:tz_europe)             echo "Europe" ;;
        fr:tz_asia)               echo "Asie" ;;
        fr:tz_africa)             echo "Afrique" ;;
        fr:tz_pacific)            echo "Pacifique" ;;
        fr:tz_atlantic)           echo "Atlantique" ;;
        fr:tz_indian)             echo "Océan Indien" ;;
        fr:tz_antarctica)         echo "Antarctique" ;;

        "fr:restart_now")         echo "Redémarrer maintenant" ;;
        "fr:poweroff_now")        echo "Éteindre maintenant" ;;


    # =============================================================
    # DEUTSCH
    # =============================================================

        de:mode)                  echo "Installationsmodus" ;;
        de:auto)                  echo "Festplatte löschen (automatisch)" ;;
        de:manual)                echo "Manuell (fortgeschritten)" ;;
        de:disk)                  echo "Zieldatenträger auswählen" ;;

        de:warn)                  echo "WARNUNG! Alle Daten werden gelöscht auf" ;;
        de:warn2)                 echo "⚠ ALLE DATEN WERDEN GELÖSCHT ⚠" ;;

        de:part)                  echo "Partitionierung und Formatierung..." ;;
        de:preparing_copy)        echo "Installation wird vorbereitet..." ;;
        de:install_counting)      echo "Dateien zum Kopieren werden berechnet..." ;;
        de:install)               echo "PimersusOS (32-Bit) wird installiert..." ;;
        de:done)                  echo "Installation erfolgreich abgeschlossen!" ;;

        de:finish_question)       echo "Was möchten Sie jetzt tun?" ;;

        de:user)                  echo "Benutzername" ;;
        de:pass)                  echo "Passwort" ;;
        de:confirm)               echo "Passwort bestätigen" ;;
        de:root_pass)             echo "Root-Passwort" ;;
        de:host)                  echo "Rechnername (Hostname)" ;;

        de:user_exists)           echo "Fehler: Benutzer existiert bereits" ;;
        de:user_invalid)          echo "Ungültiger Name. Nur Kleinbuchstaben, Zahlen und Bindestriche." ;;

        de:pass_empty)            echo "Fehler: Passwort darf nicht leer sein" ;;
        de:pass_mismatch)         echo "Fehler: Passwörter stimmen nicht überein" ;;
        de:pass_mismatch_or_empty) echo "Fehler: Passwort leer oder stimmt nicht überein" ;;

        de:creating_user_msg)     echo "Benutzerkonten werden konfiguriert..." ;;
        de:create_user)           echo "Benutzer wird erstellt..." ;;
        de:set_user_pass)         echo "Benutzerpasswort wird gesetzt..." ;;
        de:set_root_pass)         echo "Root-Passwort wird gesetzt..." ;;
        de:add_sudo)              echo "Benutzer zur sudo-Gruppe hinzufügen..." ;;
        de:processing_user)       echo "Benutzer wird verarbeitet..." ;;
        de:user_done)             echo "Benutzer erfolgreich konfiguriert." ;;

        de:no_disks)              echo "Keine verfügbaren Datenträger gefunden." ;;
        de:disk_busy)             echo "Fehler: Datenträger ist eingehängt oder in Verwendung." ;;
        de:part_fail)             echo "Fehler: Partitionierung fehlgeschlagen." ;;

        de:format_efi)            echo "EFI-Partition als FAT32 formatieren?" ;;
        de:format_root)           echo "ROOT-Partition als ext4 formatieren?" ;;

        de:detect_systems)        echo "Systemerkennung wird konfiguriert..." ;;
        de:grub_step)             echo "GRUB i386 wird installiert..." ;;
        de:install_grub_uefi)     echo "GRUB i386-efi (UEFI 32-Bit) wird installiert..." ;;
        de:install_grub_legacy)   echo "GRUB i386-pc (BIOS Legacy) wird installiert..." ;;
        de:update_grub)           echo "GRUB-Konfiguration wird generiert..." ;;
        de:efi_fallback)          echo "EFI-Fallback (BOOTIA32.EFI) wird konfiguriert..." ;;
        de:removable_mode)        echo "Wechseldatenträger-Modus i386-efi wird installiert..." ;;
        de:grub_done)             echo "GRUB erfolgreich installiert." ;;

        de:cleanup_start)         echo "Dateisysteme werden ausgehängt..." ;;
        de:cleanup_done)          echo "Abschließende Bereinigung abgeschlossen." ;;

        de:tz_region)             echo "Zeitzonenregion auswählen" ;;
        de:tz_zone)               echo "Zeitzone auswählen" ;;
        de:tz_america)            echo "Amerika" ;;
        de:tz_europe)             echo "Europa" ;;
        de:tz_asia)               echo "Asien" ;;
        de:tz_africa)             echo "Afrika" ;;
        de:tz_pacific)            echo "Pazifik" ;;
        de:tz_atlantic)           echo "Atlantik" ;;
        de:tz_indian)             echo "Indischer Ozean" ;;
        de:tz_antarctica)         echo "Antarktis" ;;

        de:restart_now)          echo "Jetzt neu starten" ;;
        de:poweroff_now)         echo "Computer ausschalten" ;;


    # =============================================================
    # FALLBACK
    # =============================================================

        *)
            case "$1" in

                mode)                    echo "Installation mode" ;;
                auto)                    echo "Erase disk (automatic)" ;;
                manual)                  echo "Manual (advanced)" ;;
                disk)                    echo "Select target disk" ;;

                install)                 echo "Installing system..." ;;
                done)                    echo "Installation completed!" ;;

                user_exists)             echo "Error: User already exists" ;;
                user_invalid)            echo "Invalid username." ;;

                pass_empty)              echo "Error: Password cannot be empty" ;;
                pass_mismatch)           echo "Error: Passwords do not match" ;;
                pass_mismatch_or_empty)  echo "Error: Passwords are empty or do not match" ;;

                creating_user_msg)       echo "Configuring users..." ;;

                no_disks)                echo "No disks found." ;;
                disk_busy)               echo "Error: Disk is busy." ;;
                part_fail)               echo "Partition creation failed." ;;

                format_efi)              echo "Format EFI partition as FAT32?" ;;
                format_root)             echo "Format ROOT partition as ext4?" ;;

                warn2)                   echo "⚠ ALL DATA WILL BE ERASED ⚠" ;;
                install_counting)        echo "Calculating files..." ;;

                install_grub_uefi)       echo "Installing GRUB i386-efi..." ;;
                install_grub_legacy)     echo "Installing GRUB i386-pc..." ;;
                efi_fallback)            echo "Configuring EFI fallback BOOTIA32.EFI..." ;;
                removable_mode)          echo "Installing removable mode..." ;;

                tz_region)               echo "Select timezone region" ;;
                tz_zone)                 echo "Select timezone" ;;
                tz_america)              echo "America" ;;
                tz_europe)               echo "Europe" ;;
                tz_asia)                 echo "Asia" ;;
                tz_africa)               echo "Africa" ;;
                tz_pacific)              echo "Pacific" ;;
                tz_atlantic)             echo "Atlantic" ;;
                tz_indian)               echo "Indian Ocean" ;;
                tz_antarctica)           echo "Antarctica" ;;

                restart_now)             echo "Restart now" ;;
                poweroff_now)            echo "Power off" ;;

                *)                       echo "$1" ;;

            esac
        ;;
    esac
}
