#!/usr/bin/env bash

# =================================================================
# PimersusOS - Instalación de GRUB (i386 / 32 bits)
# Soporte para BIOS (i386-pc) y UEFI (i386-efi)
# =================================================================

# Log interno para debugging
GRUB_LOG="${GRUB_LOG:-/tmp/grub-install.log}"

_log() {
    echo "[$(date '+%H:%M:%S')] $*" | tee -a "$GRUB_LOG"
}

install_grub(){

    dialog --infobox "$(t grub_step)" 5 50 <"$TTY" >"$TTY" 2>"$TTY"

    # =========================
    # VALIDACIONES
    # =========================

    if [[ $EUID -ne 0 ]]; then
        msg "Error: Este script debe ejecutarse como root (sudo)."
        exit 1
    fi

    _assert_target

    [[ -z "${TARGET:-}" ]] && {
        msg "Error: TARGET no definido"
        exit 1
    }

    [[ ! -d "$TARGET" ]] && {
        msg "Error: TARGET '$TARGET' no existe o no es un directorio"
        exit 1
    }

    [[ -z "${DISK:-}" ]] && {
        msg "Error: DISK no definido"
        exit 1
    }

    [[ ! -b "$DISK" ]] && {
        msg "Error: DISK '$DISK' no es un dispositivo de bloque válido"
        exit 1
    }

    local BOOT_ID="${BOOT_ID:-PimersusOS}"
    BOOT_ID=$(echo "$BOOT_ID" | tr -cs '[:alnum:]_-' '_')
    BOOT_ID="${BOOT_ID:0:20}"

    local GRUB_CFG="$TARGET/etc/default/grub"

    _log "TARGET=$TARGET  DISK=$DISK  BOOT_ID=$BOOT_ID"

    # =========================
    # MONTAR PSEUDO-SISTEMAS
    # =========================
    _log "Montando pseudo-sistemas en $TARGET ..."
    declare -a _MOUNTED_BY_US=()

    _mount_pseudo(){
        local mp="$1"
        local full="$TARGET/$mp"
        mkdir -p "$full"
        if mountpoint -q "$full" 2>/dev/null; then return 0; fi

        case "$mp" in
            proc) mount -t proc proc "$full" ;;
            sys)  mount -t sysfs sysfs "$full" ;;
            dev)  mount --bind /dev "$full" ;;
            dev/pts) mount --bind /dev/pts "$full" ;;
            dev/shm) mount --bind /dev/shm "$full" 2>/dev/null || mount -t tmpfs tmpfs "$full" ;;
            run)  mount --bind /run "$full" ;;
        esac

        if mountpoint -q "$full" 2>/dev/null; then
            _MOUNTED_BY_US+=("$full")
        fi
    }

    for mp in proc sys dev dev/pts dev/shm run; do
        _mount_pseudo "$mp"
    done

    _umount_pseudo(){
        _log "Desmontando pseudo-sistemas..."
        for (( i=${#_MOUNTED_BY_US[@]}-1; i>=0; i-- )); do
            umount "${_MOUNTED_BY_US[$i]}" 2>/dev/null
        done
    }
    trap _umount_pseudo EXIT

    # =========================
    # INSTALAR GRUB EN EL TARGET (CORRECCIÓN --REINSTALL)
    # =========================
    # Verificamos si existe el binario en la ruta de sistema del chroot
    if ! chroot "$TARGET" [ -f /usr/sbin/grub-install ]; then

        dialog --infobox "Instalando/Reparando GRUB en el sistema destino..." 5 55 \
            <"$TTY" >"$TTY" 2>"$TTY"

        _log "grub-install no detectado en /usr/sbin/, forzando instalación..."

        cp -L /etc/resolv.conf "$TARGET/etc/resolv.conf" 2>/dev/null || true

        chroot "$TARGET" apt-get update -qq >> "$GRUB_LOG" 2>&1

        if [[ -d /sys/firmware/efi ]]; then
            # Forzamos reinstalación para asegurar binarios en Debian 13/antiX
            chroot "$TARGET" apt-get install -y --reinstall grub-efi-ia32 grub-efi-ia32-bin >> "$GRUB_LOG" 2>&1 || {
                msg "Error: No se pudo instalar grub-efi-ia32"
                exit 1
            }
        else
            # Forzamos reinstalación para evitar el error de "ya instalado" pero faltante
            chroot "$TARGET" apt-get install -y --reinstall grub-pc grub-pc-bin >> "$GRUB_LOG" 2>&1 || {
                msg "Error: No se pudo instalar grub-pc"
                exit 1
            }
        fi
        _log "GRUB reinstalado en el target correctamente"
    fi

    # =========================
    # VALIDAR BINARIOS (Ruta absoluta)
    # =========================
    if ! chroot "$TARGET" [ -f /usr/sbin/grub-install ]; then
        msg "Error: grub-install sigue sin encontrarse en /usr/sbin/.\nRevisa el log en $GRUB_LOG"
        exit 1
    fi

    # =========================
    # CONFIGURAR OS-PROBER
    # =========================
    if [[ -f "$GRUB_CFG" ]]; then
        sed -i '/GRUB_DISABLE_OS_PROBER/d' "$GRUB_CFG"
        sed -i '/GRUB_TIMEOUT_STYLE/d'     "$GRUB_CFG"
        echo "GRUB_DISABLE_OS_PROBER=false" >> "$GRUB_CFG"
        echo "GRUB_TIMEOUT_STYLE=menu"      >> "$GRUB_CFG"
    fi

    # =========================
    # INSTALACIÓN FINAL (UEFI o BIOS)
    # =========================
    if [[ -d /sys/firmware/efi ]]; then
        [[ -z "${EFI:-}" ]] && { msg "Error: EFI no definida"; exit 1; }
        dialog --infobox "$(t install_grub_uefi)" 5 50 <"$TTY" >"$TTY" 2>"$TTY"
        
        mkdir -p "$TARGET/boot/efi/EFI/BOOT"

        chroot "$TARGET" /usr/sbin/grub-install \
            --target=i386-efi \
            --efi-directory=/boot/efi \
            --bootloader-id="$BOOT_ID" \
            --recheck >> "$GRUB_LOG" 2>&1 || {
                msg "Error: grub-install i386-efi falló."; exit 1;
            }
    else
        dialog --infobox "$(t install_grub_legacy)" 5 50 <"$TTY" >"$TTY" 2>"$TTY"
        _log "Modo BIOS Legacy. DISK=$DISK"

        chroot "$TARGET" /usr/sbin/grub-install \
            --target=i386-pc \
            --recheck \
            "$DISK" >> "$GRUB_LOG" 2>&1 || {
                msg "Error: grub-install i386-pc falló en $DISK."; exit 1;
            }
    fi

    # =========================
    # GENERAR CONFIGURACIÓN
    # =========================
    dialog --infobox "$(t update_grub)" 5 50 <"$TTY" >"$TTY" 2>"$TTY"
    export OS_PROBER_DISABLE_TIMEOUT=0

    _log "Generando grub.cfg..."
    if chroot "$TARGET" command -v update-grub >/dev/null 2>&1; then
        timeout 60 chroot "$TARGET" update-grub >> "$GRUB_LOG" 2>&1
    else
        timeout 60 chroot "$TARGET" grub-mkconfig -o /boot/grub/grub.cfg >> "$GRUB_LOG" 2>&1
    fi

    sync
    dialog --infobox "$(t grub_done)" 5 45 <"$TTY" >"$TTY" 2>"$TTY"
    _log "Instalación completada exitosamente."
}
