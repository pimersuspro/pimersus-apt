#!/usr/bin/env bash

# =================================================================
# PimersusOS Installer — i386 / 32 bits
# Basado en antiX / Debian 13
# =================================================================

set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# =========================
# CARGAR MÓDULOS
# =========================
source "$SCRIPT_DIR/lib/ui.sh"
source "$SCRIPT_DIR/lib/i18n.sh"
source "$SCRIPT_DIR/lib/utils.sh"
source "$SCRIPT_DIR/lib/disk.sh"
source "$SCRIPT_DIR/lib/system.sh"
source "$SCRIPT_DIR/lib/copy_system.sh"
source "$SCRIPT_DIR/lib/system_config.sh"
source "$SCRIPT_DIR/lib/users.sh"
source "$SCRIPT_DIR/lib/grub.sh"

# =========================
# VALIDAR ROOT
# =========================
if [[ $EUID -ne 0 ]]; then
    echo "ERROR: Este instalador debe ejecutarse como root." >&2
    exit 1
fi

# =========================
# LOGGING
# =========================
init_log

# =========================
# MANEJO GLOBAL DE ERRORES
# =========================
error_handler(){

    local exit_code=$?

    # Evitar recursión si cleanup falla
    trap - ERR

    echo "[error] Instalación abortada (exit code: $exit_code) — $(date)"

    msg "Ha ocurrido un error durante la instalación.\nSe intentará limpiar el sistema montado."

    cleanup || true

    # Flush del log
    sync

    exit "$exit_code"
}

trap error_handler ERR

# =========================
# FLUJO PRINCIPAL
# =========================
select_language

check_live

check_uefi

# Validar dependencias antes de tocar discos
check_dependencies

detect_systems

select_mode

setup_disks

mount_target

copy_system

configure_system

create_users

install_grub

cleanup

finish
