#!/usr/bin/env bash

# =================================================================
# PimersusOS - Montaje del sistema destino (UEFI + Legacy)
# TARGET se define en utils.sh
# =================================================================

mount_target(){

    [[ -z "$ROOT" ]] && { msg "Error: ROOT no definido"; exit 1; }

    # Desmontar si ya estaba montado de un intento anterior
    umount -R "$TARGET" 2>/dev/null || true
    mkdir -p "$TARGET"
    mount "$ROOT" "$TARGET"

    # Montar EFI solo en modo UEFI y si la variable existe
    if [[ -d /sys/firmware/efi && -n "${EFI:-}" ]]; then
        mkdir -p "$TARGET/boot/efi"
        mount "$EFI" "$TARGET/boot/efi"
    fi

    # Bind mounts necesarios para chroot
    for i in dev proc sys run; do
        mkdir -p "$TARGET/$i"
        mountpoint -q "$TARGET/$i" && continue
        mount --bind "/$i" "$TARGET/$i"
    done

    # devpts: necesario para terminales dentro del chroot
    mkdir -p "$TARGET/dev/pts"
    mountpoint -q "$TARGET/dev/pts" || mount -t devpts devpts "$TARGET/dev/pts"
}
