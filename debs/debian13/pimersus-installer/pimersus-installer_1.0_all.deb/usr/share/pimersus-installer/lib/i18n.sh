#!/usr/bin/env bash

# =================================================================
# PimersusOS - Sistema de Internacionalización (i18n)
# =================================================================

select_language(){
    LANG_CHOICE=$(dialog --stdout \
        --menu "Select Language / Seleccione Idioma" 12 50 4 \
        "en" "English" \
        "es" "Español" \
        "fr" "Français" \
        "de" "Deutsch")

    [[ -z "$LANG_CHOICE" ]] && LANG_CHOICE="en"
    export LANG_CHOICE
}

t(){
    case "$LANG_CHOICE:$1" in

        # ── Español ───────────────────────────────────────────────
        es:mode)               echo "Modo de instalación" ;;
        es:auto)               echo "Borrar disco (automático)" ;;
        es:manual)             echo "Manual (avanzado)" ;;
        es:disk)               echo "Selecciona el disco de destino" ;;
        es:warn)               echo "¡ADVERTENCIA! Se borrará TODO en" ;;
        es:warn2)              echo "⚠ ESTO BORRARÁ TODOS LOS DATOS ⚠" ;;
        es:part)               echo "Limpiando y formateando disco..." ;;
        es:preparing_copy)     echo "Preparando la instalación..." ;;
        es:install)            echo "Instalando PimersusOS..." ;;
        es:grub_step)          echo "Configurando el arranque (GRUB)..." ;;
        es:done)               echo "¡Instalación completada con éxito!" ;;

        es:user)               echo "Nombre de usuario" ;;
        es:pass)               echo "Contraseña" ;;
        es:confirm)            echo "Confirmar contraseña" ;;
        es:root_pass)          echo "Contraseña de Root (Administrador)" ;;
        es:host)               echo "Nombre del equipo (Hostname)" ;;

        es:user_exists)        echo "Error: El usuario ya existe en el sistema" ;;
        es:pass_mismatch)      echo "Error: Las contraseñas no coinciden" ;;
        es:pass_empty)         echo "Error: La contraseña no puede estar vacía" ;;
        es:creating_user_msg)  echo "Configurando cuentas de usuario..." ;;
        es:user_invalid)       echo "Nombre de usuario inválido. Use solo letras minúsculas, números y guiones." ;;

        es:format_efi)         echo "¿Formatear la partición EFI como FAT32?" ;;
        es:format_root)        echo "¿Formatear la partición ROOT como ext4?" ;;
        es:no_disks)           echo "No se encontraron discos disponibles." ;;
        es:disk_busy)          echo "Error: El disco está en uso o montado." ;;
        es:part_fail)          echo "Error: Falló la creación de particiones." ;;

        es:create_user)        echo "Creando usuario..." ;;
        es:set_user_pass)      echo "Configurando contraseña del usuario..." ;;
        es:set_root_pass)      echo "Configurando contraseña root..." ;;
        es:add_sudo)           echo "Agregando usuario al grupo sudo..." ;;
        es:user_done)          echo "Usuarios configurados correctamente." ;;

        es:detect_systems)     echo "Configurando detección de sistemas..." ;;
        es:install_grub_uefi)  echo "Instalando GRUB UEFI..." ;;
        es:install_grub_legacy) echo "Instalando GRUB Legacy..." ;;
        es:update_grub)        echo "Generando configuración GRUB..." ;;
        es:efi_fallback)       echo "Configurando fallback EFI..." ;;
        es:removable_mode)     echo "Instalando modo removible..." ;;
        es:grub_done)          echo "GRUB instalado correctamente." ;;

        es:cleanup_start)      echo "Desmontando sistemas de archivos..." ;;
        es:cleanup_done)       echo "Limpieza final completada." ;;


        # ── English ───────────────────────────────────────────────
        en:mode)               echo "Installation mode" ;;
        en:auto)               echo "Erase disk (automatic)" ;;
        en:manual)             echo "Manual (advanced)" ;;
        en:disk)               echo "Select target disk" ;;
        en:warn)               echo "WARNING! ALL data will be erased on" ;;
        en:warn2)              echo "⚠ THIS WILL ERASE ALL DATA ⚠" ;;
        en:part)               echo "Partitioning and formatting..." ;;
        en:preparing_copy)     echo "Preparing installation..." ;;
        en:install)            echo "Installing PimersusOS..." ;;
        en:grub_step)          echo "Installing GRUB bootloader..." ;;
        en:done)               echo "Installation completed successfully!" ;;

        en:user)               echo "Username" ;;
        en:pass)               echo "Password" ;;
        en:confirm)            echo "Confirm Password" ;;
        en:root_pass)          echo "Root Password" ;;
        en:host)               echo "Hostname" ;;

        en:user_exists)        echo "Error: User already exists in the system" ;;
        en:pass_mismatch)      echo "Error: Passwords do not match" ;;
        en:pass_empty)         echo "Error: Password cannot be empty" ;;
        en:creating_user_msg)  echo "Configuring user accounts..." ;;
        en:user_invalid)       echo "Invalid username. Use only lowercase letters, numbers and hyphens." ;;

        en:format_efi)         echo "Format EFI partition as FAT32?" ;;
        en:format_root)        echo "Format ROOT partition as ext4?" ;;
        en:no_disks)           echo "No available disks found." ;;
        en:disk_busy)          echo "Error: Disk is currently mounted or in use." ;;
        en:part_fail)          echo "Error: Partition creation failed." ;;

        en:create_user)        echo "Creating user..." ;;
        en:set_user_pass)      echo "Setting user password..." ;;
        en:set_root_pass)      echo "Setting root password..." ;;
        en:add_sudo)           echo "Adding user to sudo group..." ;;
        en:user_done)          echo "Users configured successfully." ;;

        en:detect_systems)     echo "Configuring system detection..." ;;
        en:install_grub_uefi)  echo "Installing GRUB UEFI..." ;;
        en:install_grub_legacy) echo "Installing GRUB Legacy..." ;;
        en:update_grub)        echo "Generating GRUB configuration..." ;;
        en:efi_fallback)       echo "Configuring EFI fallback..." ;;
        en:removable_mode)     echo "Installing removable mode..." ;;
        en:grub_done)          echo "GRUB installed successfully." ;;

        en:cleanup_start)      echo "Unmounting filesystems..." ;;
        en:cleanup_done)       echo "Final cleanup completed." ;;


        # ── Français ──────────────────────────────────────────────
        fr:mode)               echo "Mode d'installation" ;;
        fr:auto)               echo "Effacer le disque (automatique)" ;;
        fr:manual)             echo "Manuel (avancé)" ;;
        fr:disk)               echo "Sélectionnez le disque cible" ;;
        fr:warn)               echo "ATTENTION ! Toutes les données seront effacées sur" ;;
        fr:warn2)              echo "⚠ TOUTES LES DONNÉES SERONT EFFACÉES ⚠" ;;
        fr:part)               echo "Partitionnement et formatage..." ;;
        fr:preparing_copy)     echo "Préparation de l'installation..." ;;
        fr:install)            echo "Installation de PimersusOS..." ;;
        fr:grub_step)          echo "Installation de GRUB..." ;;
        fr:done)               echo "Installation terminée avec succès !" ;;

        de:mode)               echo "Installationsmodus" ;;
        de:auto)               echo "Festplatte löschen (automatisch)" ;;
        de:manual)             echo "Manuell (fortgeschritten)" ;;
        de:disk)               echo "Zieldatenträger auswählen" ;;
        de:warn)               echo "WARNUNG! Alle Daten werden gelöscht auf" ;;
        de:warn2)              echo "⚠ ALLE DATEN WERDEN GELÖSCHT ⚠" ;;
        de:part)               echo "Partitionierung und Formatierung..." ;;
        de:preparing_copy)     echo "Installation wird vorbereitet..." ;;
        de:install)            echo "PimersusOS wird installiert..." ;;
        de:grub_step)          echo "GRUB wird installiert..." ;;
        de:done)               echo "Installation erfolgreich abgeschlossen!" ;;

        # ── Fallback ──────────────────────────────────────────────
        *)
            case "$1" in
                user_exists)       echo "Error: User already exists" ;;
                pass_mismatch)     echo "Error: Passwords do not match" ;;
                pass_empty)        echo "Error: Password cannot be empty" ;;
                creating_user_msg) echo "Configuring users..." ;;
                user_invalid)      echo "Invalid username." ;;
                no_disks)          echo "No disks found." ;;
                disk_busy)         echo "Error: Disk is busy." ;;
                part_fail)         echo "Partition creation failed." ;;
                format_efi)        echo "Format EFI partition as FAT32?" ;;
                format_root)       echo "Format ROOT partition as ext4?" ;;
                warn2)             echo "⚠ ALL DATA WILL BE ERASED ⚠" ;;
                *)                 echo "$1" ;;
            esac
        ;;
    esac
}