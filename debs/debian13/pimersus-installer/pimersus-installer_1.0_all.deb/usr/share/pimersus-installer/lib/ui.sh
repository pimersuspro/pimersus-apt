#!/usr/bin/env bash

# =================================================================
# PimersusOS - Funciones de interfaz de usuario (UI)
# =================================================================

msg(){
    dialog --msgbox "$1" 8 60
}

menu(){
    local title="$1"
    shift
    dialog --stdout \
        --menu "$title" 15 60 8 \
        "$@"
}

input(){
    local label="$1"
    local default="$2"
    dialog --stdout \
        --inputbox "$label" 8 50 "$default"
}

password(){
    local label="$1"
    dialog --stdout \
        --passwordbox "$label" 8 50
}