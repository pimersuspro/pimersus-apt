#!/usr/bin/env bash

# =================================================================
# PimersusOS - Copia del sistema live al disco destino
# =================================================================

copy_system(){

    dialog --infobox "$(t install)" 5 50 <"$TTY" >"$TTY" 2>"$TTY"

    # =========================
    # VERIFICACIÓN PREVIA
    # =========================
    [[ -z "$TARGET" ]] && { msg "Error: TARGET no definido"; exit 1; }
    mountpoint -q "$TARGET" || { msg "Error: $TARGET no está montado"; exit 1; }

    # =========================
    # COPIA CON RSYNC
    # =========================
    rsync -aAXH \
        --info=progress2 \
        --exclude=/proc \
        --exclude=/sys \
        --exclude=/dev \
        --exclude=/run \
        --exclude=/tmp \
        --exclude=/mnt \
        --exclude=/media \
        --exclude=/lost+found \
        --exclude=/boot/efi \
        --exclude=/target \
        / "$TARGET/" 2>/dev/null

    # =========================
    # CREAR DIRS NECESARIOS
    # =========================
    mkdir -p "$TARGET"/{proc,sys,dev,run,tmp,mnt,media}
    chmod 1777 "$TARGET/tmp"

    # =========================
    # FSTAB
    # =========================
    local ROOT_UUID
    ROOT_UUID=$(blkid -s UUID -o value "$ROOT")

    if [[ -d /sys/firmware/efi && -n "${EFI:-}" ]]; then
        # UEFI: incluir línea EFI en fstab
        local EFI_UUID
        EFI_UUID=$(blkid -s UUID -o value "$EFI")
        cat > "$TARGET/etc/fstab" <<EOF
# PimersusOS fstab — generado por el instalador
UUID=$ROOT_UUID /         ext4  errors=remount-ro    0 1
UUID=$EFI_UUID  /boot/efi vfat  umask=0077           0 2
tmpfs           /tmp      tmpfs defaults,nosuid,nodev 0 0
EOF
    else
        # Legacy/BIOS: sin partición EFI
        cat > "$TARGET/etc/fstab" <<EOF
# PimersusOS fstab — generado por el instalador
UUID=$ROOT_UUID /         ext4  errors=remount-ro    0 1
tmpfs           /tmp      tmpfs defaults,nosuid,nodev 0 0
EOF
    fi

    sync
}
