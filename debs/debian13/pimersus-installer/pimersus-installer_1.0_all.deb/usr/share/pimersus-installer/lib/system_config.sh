#!/usr/bin/env bash

# =================================================================
# PimersusOS - Configuración del sistema instalado
# =================================================================

configure_system(){

    # =========================
    # HOSTNAME
    # =========================
    HOSTNAME=$(input "$(t host)" "pimersus")
    [[ -z "$HOSTNAME" ]] && HOSTNAME="pimersus"
    # Sanitizar: solo letras, números y guiones
    HOSTNAME=$(echo "$HOSTNAME" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9-]/-/g')

    echo "$HOSTNAME" > "$TARGET/etc/hostname"

    cat > "$TARGET/etc/hosts" <<EOF
127.0.0.1   localhost
127.0.1.1   $HOSTNAME
::1         localhost ip6-localhost ip6-loopback
EOF

    # =========================
    # LOCALES
    # =========================
    # Siempre incluir en_US como base
    echo "en_US.UTF-8 UTF-8" > "$TARGET/etc/locale.gen"

    local FINAL_LANG KMAP
    case "$LANG_CHOICE" in
        es)
            echo "es_ES.UTF-8 UTF-8" >> "$TARGET/etc/locale.gen"
            FINAL_LANG="es_ES.UTF-8"
            KMAP="es"
            ;;
        fr)
            echo "fr_FR.UTF-8 UTF-8" >> "$TARGET/etc/locale.gen"
            FINAL_LANG="fr_FR.UTF-8"
            KMAP="fr"
            ;;
        de)
            echo "de_DE.UTF-8 UTF-8" >> "$TARGET/etc/locale.gen"
            FINAL_LANG="de_DE.UTF-8"
            KMAP="de"
            ;;
        *)
            FINAL_LANG="en_US.UTF-8"
            KMAP="us"
            ;;
    esac

    chroot "$TARGET" locale-gen
    echo "LANG=$FINAL_LANG" > "$TARGET/etc/locale.conf"
    chroot "$TARGET" update-locale LANG="$FINAL_LANG" 2>/dev/null || true

    # =========================
    # TECLADO
    # =========================
    cat > "$TARGET/etc/default/keyboard" <<EOF
XKBMODEL="pc105"
XKBLAYOUT="$KMAP"
XKBVARIANT=""
XKBOPTIONS=""
BACKSPACE="guess"
EOF

    # =========================
    # RED
    # =========================
    # Detectar si el sistema destino tiene NetworkManager instalado
    if chroot "$TARGET" which NetworkManager &>/dev/null || \
       [[ -f "$TARGET/etc/NetworkManager/NetworkManager.conf" ]]; then
        # Usar NetworkManager — no crear interfaces legacy
        echo "[info] NetworkManager detectado, omitiendo /etc/network/interfaces"
    else
        # Configuración clásica con /etc/network/interfaces
        # Incluye nombres de interfaz comunes (eth0, enp*, ens*, eno*)
        cat > "$TARGET/etc/network/interfaces" <<EOF
# PimersusOS - network interfaces
auto lo
iface lo inet loopback

# Interfaz Ethernet clásica
allow-hotplug eth0
iface eth0 inet dhcp

# Interfaces con nombres predecibles (systemd/udev)
allow-hotplug enp0s3
iface enp0s3 inet dhcp

allow-hotplug enp1s0
iface enp1s0 inet dhcp

allow-hotplug ens3
iface ens3 inet dhcp

allow-hotplug eno1
iface eno1 inet dhcp
EOF
    fi

    # =========================
    # TIMEZONE
    # =========================
    # Establecer UTC como zona horaria base (el usuario puede cambiarla luego)
    chroot "$TARGET" ln -sf /usr/share/zoneinfo/UTC /etc/localtime 2>/dev/null || true
}
