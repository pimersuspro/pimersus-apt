#!/usr/bin/env bash

# =================================================================
# PimersusOS - Creación y configuración de usuarios
# =================================================================

create_users(){

    dialog --infobox "$(t creating_user_msg)" 5 55 <"$TTY" >"$TTY" 2>"$TTY"

    local DEFAULT_USER="pimersus"

    # =========================
    # NOMBRE DE USUARIO
    # =========================
    local USERNAME
    while true; do
        USERNAME=$(input "$(t user)" "$DEFAULT_USER")

        # Validar formato
        if [[ "$USERNAME" =~ ^[a-z_][a-z0-9_-]*$ ]]; then
            break
        else
            msg "$(t user_invalid)"
        fi
    done

    # =========================
    # CONTRASEÑA DEL USUARIO
    # =========================
    local PASS1 PASS2
    while true; do
        PASS1=$(password "$(t pass)")
        PASS2=$(password "$(t confirm)")

        if [[ -z "$PASS1" ]]; then
            msg "$(t pass_empty)"
        elif [[ "$PASS1" != "$PASS2" ]]; then
            msg "$(t pass_mismatch)"
        else
            break
        fi
    done

    # =========================
    # CONTRASEÑA ROOT
    # =========================
    local ROOTPASS
    while true; do
        ROOTPASS=$(password "$(t root_pass)")

        [[ -n "$ROOTPASS" ]] && break
        msg "$(t pass_empty)"
    done

    # =========================
    # CREAR / REUTILIZAR / RENOMBRAR
    # =========================
    dialog --infobox "$(t create_user)" 5 45 <"$TTY" >"$TTY" 2>"$TTY"

    if chroot "$TARGET" id "$DEFAULT_USER" &>/dev/null; then

        # Usuario live/default existe
        if [[ "$USERNAME" != "$DEFAULT_USER" ]]; then
            echo "[info] Renaming user '$DEFAULT_USER' -> '$USERNAME'"

            chroot "$TARGET" usermod -l "$USERNAME" "$DEFAULT_USER" \
                || { msg "Error: usermod -l failed"; return 1; }

            chroot "$TARGET" usermod -d "/home/$USERNAME" -m "$USERNAME" \
                || { msg "Error: move HOME failed"; return 1; }
        else
            echo "[info] Reusing default user '$DEFAULT_USER'"
        fi

    elif chroot "$TARGET" id "$USERNAME" &>/dev/null; then
        echo "[info] user '$USERNAME' It already exists, reusing."

    else
        chroot "$TARGET" useradd -m -s /bin/bash "$USERNAME" \
            || { msg "Error: useradd failed"; return 1; }
    fi

    # =========================
    # PASSWORD USUARIO
    # =========================
    dialog --infobox "$(t set_user_pass)" 5 55 <"$TTY" >"$TTY" 2>"$TTY"
    echo "$USERNAME:$PASS1" | chroot "$TARGET" chpasswd \
        || { msg "Error: chpasswd user failed"; return 1; }

    # =========================
    # PASSWORD ROOT
    # =========================
    dialog --infobox "$(t set_root_pass)" 5 50 <"$TTY" >"$TTY" 2>"$TTY"
    echo "root:$ROOTPASS" | chroot "$TARGET" chpasswd \
        || { msg "Error: chpasswd root failed"; return 1; }

    # =========================
    # SUDO
    # =========================
    dialog --infobox "$(t add_sudo)" 5 50 <"$TTY" >"$TTY" 2>"$TTY"
    chroot "$TARGET" usermod -aG sudo "$USERNAME" \
        || { msg "Error: usermod sudo failed"; return 1; }

    # =========================
    # FINAL
    # =========================
    dialog --infobox "$(t user_done)" 5 50 <"$TTY" >"$TTY" 2>"$TTY"

    echo "[info] configured end user: '$USERNAME'"
}