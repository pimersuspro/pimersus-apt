#!/usr/bin/env bash

# =================================================================
# PimersusOS - Instalación de GRUB (UEFI + Legacy)
# Requiere que $DISK esté exportado desde disk.sh
# =================================================================

install_grub(){

    dialog --infobox "$(t grub_step)" 5 50 <"$TTY" >"$TTY" 2>"$TTY"

    set -e

    # =========================
    # VALIDACIONES
    # =========================
    [[ -z "$TARGET" ]] && { msg "Error: TARGET no definido"; exit 1; }
    [[ -z "$DISK"   ]] && { msg "Error: DISK no definido";   exit 1; }

    local BOOT_ID="${BOOT_ID:-PimersusOS}"

    # Sanitizar BOOT_ID
    BOOT_ID=$(echo "$BOOT_ID" | tr -cs '[:alnum:]-_' '_')

    local GRUB_CFG="$TARGET/etc/default/grub"

    # =========================
    # CONFIGURAR OS-PROBER
    # =========================
    dialog --infobox "$(t detect_systems)" 5 50 <"$TTY" >"$TTY" 2>"$TTY"

    if grep -q "^GRUB_DISABLE_OS_PROBER" "$GRUB_CFG" 2>/dev/null; then
        sed -i 's/^GRUB_DISABLE_OS_PROBER=.*/GRUB_DISABLE_OS_PROBER=false/' "$GRUB_CFG"
    else
        echo "GRUB_DISABLE_OS_PROBER=false" >> "$GRUB_CFG"
    fi

    if [[ -d /sys/firmware/efi ]]; then
        # =========================
        # MODO UEFI
        # =========================
        [[ -z "${EFI:-}" ]] && { msg "Error: EFI no definido en modo UEFI"; exit 1; }

        # -------------------------
        # INSTALAR GRUB UEFI
        # -------------------------
        dialog --infobox "$(t install_grub_uefi)" 5 45 <"$TTY" >"$TTY" 2>"$TTY"

        chroot "$TARGET" grub-install \
            --target=x86_64-efi \
            --efi-directory=/boot/efi \
            --bootloader-id="$BOOT_ID" \
            --recheck || { msg "Error: grub-install UEFI falló"; exit 1; }

        # -------------------------
        # GENERAR CONFIGURACIÓN
        # -------------------------
        dialog --infobox "$(t update_grub)" 5 50 <"$TTY" >"$TTY" 2>"$TTY"

        chroot "$TARGET" update-grub \
            || { msg "Error: update-grub falló"; exit 1; }

        # -------------------------
        # FALLBACK EFI
        # -------------------------
        dialog --infobox "$(t efi_fallback)" 5 45 <"$TTY" >"$TTY" 2>"$TTY"

        local EFI_FILE="$TARGET/boot/efi/EFI/$BOOT_ID/grubx64.efi"
        local EFI_FALLBACK="$TARGET/boot/efi/EFI/BOOT/BOOTX64.EFI"

        mkdir -p "$(dirname "$EFI_FALLBACK")"
        [[ -f "$EFI_FILE" ]] && cp -f "$EFI_FILE" "$EFI_FALLBACK"

        # -------------------------
        # INSTALACIÓN REMOVIBLE
        # -------------------------
        dialog --infobox "$(t removable_mode)" 5 45 <"$TTY" >"$TTY" 2>"$TTY"

        chroot "$TARGET" grub-install \
            --target=x86_64-efi \
            --efi-directory=/boot/efi \
            --removable \
            --recheck 2>/dev/null || true

    else
        # =========================
        # MODO LEGACY / BIOS
        # =========================

        # -------------------------
        # INSTALAR GRUB LEGACY
        # -------------------------
        dialog --infobox "$(t install_grub_legacy)" 5 45 <"$TTY" >"$TTY" 2>"$TTY"

        chroot "$TARGET" grub-install \
            --target=i386-pc \
            "$DISK" || { msg "Error: grub-install Legacy falló en $DISK"; exit 1; }

        # -------------------------
        # GENERAR CONFIGURACIÓN
        # -------------------------
        dialog --infobox "$(t update_grub)" 5 50 <"$TTY" >"$TTY" 2>"$TTY"

        chroot "$TARGET" update-grub \
            || { msg "Error: update-grub falló"; exit 1; }
    fi

    # =========================
    # FINAL
    # =========================
    dialog --infobox "$(t grub_done)" 5 45 <"$TTY" >"$TTY" 2>"$TTY"

    sync
}