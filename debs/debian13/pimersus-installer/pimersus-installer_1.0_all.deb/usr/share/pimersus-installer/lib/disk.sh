#!/usr/bin/env bash

# =================================================================
# PimersusOS - Gestión de discos (UEFI + Legacy)
# =================================================================

select_mode(){
    MODE=$(menu "$(t mode)" \
        "auto"   "$(t auto)" \
        "manual" "$(t manual)")

    [[ -z "$MODE" ]] && exit 1
    export MODE
}

setup_disks(){
    case "$MODE" in
        auto)   auto_partition ;;
        manual) manual_partition ;;
        *)      exit 1 ;;
    esac
}

# =================================================================
# Obtener discos disponibles (incluye loop para testing)
# =================================================================
get_available_disks(){
    lsblk -dn -o NAME,SIZE,TYPE | while read -r name size type; do
        [[ -z "$name" ]] && continue
        [[ "$type" != "disk" && "$type" != "loop" ]] && continue
        echo "/dev/$name|$size"
    done
}

# =================================================================
# MODO MANUAL
# =================================================================
manual_partition(){

    local OPTIONS=()

    while IFS='|' read -r dev label; do
        OPTIONS+=("$dev" "$label")
    done < <(get_available_disks)

    [[ ${#OPTIONS[@]} -eq 0 ]] && {
        msg "$(t no_disks)"
        exit 1
    }

    DISK=$(menu "$(t disk)" "${OPTIONS[@]}")
    [[ -z "$DISK" ]] && exit 1
    export DISK

    dialog --msgbox \
        "Se abrirá cfdisk. Crea tus particiones y anota los nombres (ej: ${DISK}1, ${DISK}2)." \
        8 65

    clear
    reset
    cfdisk "$DISK"
    clear

    ROOT=$(input "Introduce la partición para ROOT (ej: ${DISK}1):" "")
    [[ -z "$ROOT" ]] && exit 1
    export ROOT

    dialog --yesno "$(t format_root) ($ROOT)" 7 55 && mkfs.ext4 -F "$ROOT"

    if [[ -d /sys/firmware/efi ]]; then
        EFI=$(input "Introduce la partición EFI (ej: ${DISK}2):" "")
        [[ -z "$EFI" ]] && exit 1
        export EFI

        dialog --yesno "$(t format_efi) ($EFI)" 7 55 \
            && mkfs.fat -F32 -n EFI "$EFI"
    else
        EFI=""
        export EFI
    fi
}

# =================================================================
# MODO AUTOMÁTICO
# =================================================================
auto_partition(){

    local OPTIONS=()

    while IFS='|' read -r dev label; do
        OPTIONS+=("$dev" "$label")
    done < <(get_available_disks)

    [[ ${#OPTIONS[@]} -eq 0 ]] && {
        msg "$(t no_disks)"
        exit 1
    }

    DISK=$(menu "$(t disk)" "${OPTIONS[@]}")
    [[ -z "$DISK" ]] && exit 1
    export DISK

    # Evitar usar disco montado real
    if lsblk -no MOUNTPOINT "$DISK" | grep -q '/'; then
        msg "$(t disk_busy)"
        exit 1
    fi

    dialog --yesno "$(t warn) $DISK ?" 10 50 || exit 1
    dialog --yesno "$(t warn2)\n\n$DISK" 10 60 || exit 1
    dialog --infobox "$(t part)" 5 40

    set -e

    wipefs -af "$DISK" >/dev/null 2>&1 || true
    sgdisk --zap-all "$DISK" >/dev/null 2>&1 || true
    dd if=/dev/zero of="$DISK" bs=1M count=10 status=none || true

    local P=""
    case "$DISK" in
        *nvme*|*mmcblk*) P="p" ;;
        *loop*) P="p" ;;
    esac

    if [[ -d /sys/firmware/efi ]]; then
        # UEFI
        parted -s "$DISK" mklabel gpt
        parted -s "$DISK" mkpart ESP fat32 1MiB 513MiB
        parted -s "$DISK" set 1 esp on
        parted -s "$DISK" mkpart primary ext4 513MiB 100%

        sync
        partprobe "$DISK"
        udevadm settle

        EFI="${DISK}${P}1"
        ROOT="${DISK}${P}2"

        [[ ! -b "$EFI" || ! -b "$ROOT" ]] && {
            msg "$(t part_fail)"
            exit 1
        }

        mkfs.fat -F32 -n EFI "$EFI"
        mkfs.ext4 -F "$ROOT"

    else
        # BIOS
        parted -s "$DISK" mklabel msdos
        parted -s "$DISK" mkpart primary ext4 1MiB 100%
        parted -s "$DISK" set 1 boot on

        sync
        partprobe "$DISK"
        udevadm settle

        EFI=""
        ROOT="${DISK}${P}1"

        [[ ! -b "$ROOT" ]] && {
            msg "$(t part_fail)"
            exit 1
        }

        mkfs.ext4 -F "$ROOT"
    fi

    export EFI ROOT
    sync
}