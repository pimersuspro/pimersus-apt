#!/usr/bin/env bash

# =================================================================
# PimersusOS - Utilidades del sistema (UEFI + Legacy)
# =================================================================

# TTY global — definido una sola vez aquí, compartido por todos los módulos
TTY=/dev/tty

# Variable global del destino de instalación
TARGET="/target"

init_log(){
    LOG="/var/log/pimersus-installer.log"
    exec >> >(tee -a "$LOG") 2>&1
}

check_uefi(){
    if [[ -d /sys/firmware/efi ]]; then
        echo "[info] Modo UEFI detectado"
    else
        echo "[info] Modo Legacy/BIOS detectado"
        dialog --yesno \
            "⚠ Modo LEGACY/BIOS detectado.\nUEFI es recomendado.\n\n¿Continuar de todas formas?" \
            10 55 <"$TTY" >"$TTY" 2>"$TTY" || exit 1
    fi
}

check_live(){
    # Incluye keywords de distintos sistemas live modernos
    if ! grep -qE "overlay|overlayfs|squashfs|live|aufs|casper|toram" /proc/1/mounts 2>/dev/null && \
       ! grep -qE "overlay|overlayfs|squashfs|live|aufs|casper|toram" /proc/mounts 2>/dev/null; then
        dialog --msgbox \
            "ERROR: Debes ejecutar el instalador desde un sistema live (USB/CD)." \
            8 60 <"$TTY" >"$TTY" 2>"$TTY"
        exit 1
    fi
}

detect_systems(){
    if command -v os-prober &>/dev/null; then
        echo "[info] Detectando otros sistemas operativos..."
        local found
        found=$(os-prober 2>/dev/null || true)

        if [[ -n "$found" ]]; then
            dialog --msgbox \
                "Sistemas detectados:\n\n$found" \
                12 60 <"$TTY" >"$TTY" 2>"$TTY"
        fi
    fi
}

cleanup(){

    # =========================
    # LIMPIEZA FINAL
    # =========================
    dialog --infobox \
        "$(t cleanup_start)" \
        5 50 <"$TTY" >"$TTY" 2>"$TTY"

    local mounts=(
        "dev/pts"
        "dev"
        "run"
        "sys"
        "proc"
        "boot/efi"
    )

    for i in "${mounts[@]}"; do
        local mp="$TARGET/$i"

        if mountpoint -q "$mp" 2>/dev/null; then
            umount -l "$mp" 2>/dev/null || true
        fi
    done

    if mountpoint -q "$TARGET" 2>/dev/null; then
        umount -l "$TARGET" 2>/dev/null || true
    fi

    dialog --infobox \
        "$(t cleanup_done)" \
        5 45 <"$TTY" >"$TTY" 2>"$TTY"
}

finish(){

    # =========================
    # FINALIZACIÓN
    # =========================
    dialog --menu \
        "$(t done)\n\n¿Qué deseas hacer ahora?" \
        12 50 2 \
        "reboot"   "Reiniciar ahora" \
        "poweroff" "Apagar el equipo" \
        <"$TTY" >"$TTY" 2>/tmp/finish_choice || true

    local choice
    choice=$(cat /tmp/finish_choice 2>/dev/null || echo "reboot")

    sync
    sleep 2

    case "$choice" in
        poweroff) poweroff ;;
        *)        reboot ;;
    esac
}