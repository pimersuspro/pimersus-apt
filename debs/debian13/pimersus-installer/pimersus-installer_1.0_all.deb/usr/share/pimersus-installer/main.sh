#!/usr/bin/env bash

# =================================================================
# PimersusOS Installer - Punto de entrada principal
# =================================================================

if [ "$EUID" -ne 0 ]; then
    exec sudo "$0" "$@"
fi

set -euo pipefail

BASE_DIR="$(dirname "$(realpath "$0")")"

# ORDEN IMPORTANTE: utils primero para tener TTY, log y funciones base
source "$BASE_DIR/lib/utils.sh"
source "$BASE_DIR/lib/ui.sh"
source "$BASE_DIR/lib/i18n.sh"
source "$BASE_DIR/lib/disk.sh"
source "$BASE_DIR/lib/system.sh"
source "$BASE_DIR/lib/system_config.sh"
source "$BASE_DIR/lib/copy_system.sh"
source "$BASE_DIR/lib/users.sh"
source "$BASE_DIR/lib/grub.sh"

# Iniciar log ANTES de cualquier otra cosa
init_log

# Flujo principal
select_language
check_uefi
# check_live
detect_systems
select_mode
setup_disks
mount_target
copy_system
configure_system
create_users
install_grub
cleanup
finish
