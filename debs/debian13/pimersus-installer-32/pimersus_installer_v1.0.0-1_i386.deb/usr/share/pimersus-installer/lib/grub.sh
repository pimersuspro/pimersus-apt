#!/usr/bin/env bash

# =================================================================
# PimersusOS - Instalación de GRUB (i386 / 32 bits)
# Soporte para BIOS (i386-pc) y UEFI (i386-efi)
# =================================================================

install_grub(){

    dialog --infobox "$(t grub_step)" 5 50 <"$TTY" >"$TTY" 2>"$TTY"

    # =========================
    # VALIDACIONES
    # =========================
    _assert_target

    [[ -z "${DISK:-}" ]] && {
        msg "Error: DISK no definido"
        exit 1
    }

    local BOOT_ID="${BOOT_ID:-PimersusOS}"

    # Sanitizar y limitar longitud (más amigable con FAT/UEFI raros)
    BOOT_ID=$(echo "$BOOT_ID" | tr -cs '[:alnum:]_-' '_')
    BOOT_ID="${BOOT_ID:0:20}"

    local GRUB_CFG="$TARGET/etc/default/grub"

    # =========================
    # VALIDAR BINARIOS
    # =========================
    if ! chroot "$TARGET" command -v grub-install >/dev/null 2>&1; then
        msg "Error: grub-install no encontrado.\nInstala grub-pc o grub-efi-ia32."
        exit 1
    fi

    # =========================
    # CONFIGURAR OS-PROBER
    # =========================
    if [[ -f "$GRUB_CFG" ]]; then

        sed -i '/GRUB_DISABLE_OS_PROBER/d' "$GRUB_CFG"
        sed -i '/GRUB_TIMEOUT_STYLE/d' "$GRUB_CFG"

        echo "GRUB_DISABLE_OS_PROBER=false" >> "$GRUB_CFG"
        echo "GRUB_TIMEOUT_STYLE=menu" >> "$GRUB_CFG"
    fi

    # =========================
    # INSTALACIÓN UEFI
    # =========================
    if [[ -d /sys/firmware/efi ]]; then

        [[ -z "${EFI:-}" ]] && {
            msg "Error: Partición EFI no definida"
            exit 1
        }

        dialog --infobox "$(t install_grub_uefi)" 5 50 <"$TTY" >"$TTY" 2>"$TTY"

        mkdir -p "$TARGET/boot/efi/EFI/BOOT"

        if ! chroot "$TARGET" grub-install --print-targets | grep -q "i386-efi"; then
            msg "Error: Este sistema no tiene soporte GRUB i386-efi.\nInstala grub-efi-ia32."
            exit 1
        fi

        chroot "$TARGET" grub-install \
            --target=i386-efi \
            --efi-directory=/boot/efi \
            --bootloader-id="$BOOT_ID" \
            --recheck || {
                msg "Error: grub-install i386-efi falló"
                exit 1
            }

        chroot "$TARGET" grub-install \
            --target=i386-efi \
            --efi-directory=/boot/efi \
            --removable \
            --no-nvram || \
            echo "[warn] No se pudo instalar GRUB removable"

        local EFI_FILE="$TARGET/boot/efi/EFI/$BOOT_ID/grubia32.efi"
        local EFI_FALLBACK="$TARGET/boot/efi/EFI/BOOT/BOOTIA32.EFI"

        if [[ -f "$EFI_FILE" ]]; then
            cp -f "$EFI_FILE" "$EFI_FALLBACK" || \
                echo "[warn] No se pudo copiar fallback BOOTIA32.EFI"
        else
            echo "[warn] grubia32.efi no encontrado en EFI/$BOOT_ID"
        fi

    # =========================
    # INSTALACIÓN BIOS LEGACY
    # =========================
    else

        dialog --infobox "$(t install_grub_legacy)" 5 50 <"$TTY" >"$TTY" 2>"$TTY"

        # ---------------------------------------------------------
        # BIOS + GPT requiere bios_grub
        # ---------------------------------------------------------
        local PART_TABLE
        PART_TABLE=$(parted -s "$DISK" print 2>/dev/null | grep "Partition Table" || true)

        if echo "$PART_TABLE" | grep -qi gpt; then

            if ! parted -s "$DISK" print 2>/dev/null | grep -qi "bios_grub"; then
                msg "Error: BIOS + GPT detectado.\nSe requiere una partición bios_grub para instalar GRUB."
                exit 1
            fi
        fi

        # Verificar soporte i386-pc
        if ! chroot "$TARGET" grub-install --print-targets | grep -q "i386-pc"; then
            msg "Error: Este sistema no tiene soporte GRUB i386-pc.\nInstala grub-pc."
            exit 1
        fi

        chroot "$TARGET" grub-install \
            --target=i386-pc \
            --recheck \
            "$DISK" || {
                msg "Error: grub-install i386-pc falló en $DISK"
                exit 1
            }
    fi

    # =========================
    # GENERAR CONFIGURACIÓN
    # =========================
    dialog --infobox "$(t update_grub)" 5 50 <"$TTY" >"$TTY" 2>"$TTY"

    export OS_PROBER_DISABLE_TIMEOUT=0

    if chroot "$TARGET" command -v update-grub >/dev/null 2>&1; then

        timeout 30 chroot "$TARGET" update-grub || {
            msg "Error: update-grub falló o excedió el tiempo límite"
            exit 1
        }

    else

        timeout 30 chroot "$TARGET" grub-mkconfig -o /boot/grub/grub.cfg || {
            msg "Error: grub-mkconfig falló o excedió el tiempo límite"
            exit 1
        }
    fi

    # =========================
    # VALIDAR grub.cfg
    # =========================
    if [[ ! -f "$TARGET/boot/grub/grub.cfg" ]]; then
        msg "Error: grub.cfg no fue generado"
        exit 1
    fi

    sync

    dialog --infobox "$(t grub_done)" 5 45 <"$TTY" >"$TTY" 2>"$TTY"

    echo "[info] GRUB instalado correctamente"
}