#!/usr/bin/env bash

# =================================================================
# PimersusOS - Copia del sistema live al disco destino
# =================================================================

copy_system(){

    dialog --infobox "$(t install)" 5 50 \
        <"$TTY" >"$TTY" 2>"$TTY"

    # =================================================================
    # VALIDACIONES
    # =================================================================
    _assert_target

    [[ -z "${ROOT:-}" ]] && {
        msg "Error: ROOT no definido"
        exit 1
    }

    mountpoint -q "$TARGET" || {
        msg "Error: $TARGET no está montado"
        exit 1
    }

    # =================================================================
    # ESPACIO DISPONIBLE
    # =================================================================
    local available_kb

    available_kb=$(df -k "$TARGET" | awk 'NR==2 {print $4}')

    if [[ "$available_kb" -lt 3000000 ]]; then
        dialog --yesno \
            "⚠ Advertencia: El disco destino tiene menos de 3 GB libres.\n\n¿Continuar?" \
            10 60 <"$TTY" >"$TTY" 2>"$TTY" || exit 1
    fi

    # =================================================================
    # CONTAR ARCHIVOS
    # =================================================================
    dialog --infobox "$(t install_counting)" 5 55 \
        <"$TTY" >"$TTY" 2>"$TTY"

    local total_files

    total_files=$(
        rsync -aAXHx --sparse --dry-run \
            --exclude=/proc/* \
            --exclude=/sys/* \
            --exclude=/dev/* \
            --exclude=/run/* \
            --exclude=/tmp/* \
            --exclude=/mnt/* \
            --exclude=/media/* \
            --exclude=/lost+found \
            --exclude=/boot/efi/* \
            --exclude=/target \
            --exclude=/target/* \
            --exclude=/swapfile \
            --exclude=/var/swap/* \
            / "$TARGET/" 2>/dev/null | {
                grep -c '^' || true
            }
    )

    [[ "${total_files:-0}" -lt 1 ]] && total_files=1

    # =================================================================
    # FIFO PARA RSYNC + GAUGE
    # =================================================================
    local _RSYNC_FIFO
    _RSYNC_FIFO=$(mktemp -u /tmp/.rsync_pipe_XXXXXX)

    mkfifo "$_RSYNC_FIFO"

    local _RSYNC_PID
    local _RSYNC_RC=0

    # =================================================================
    # RSYNC EN BACKGROUND
    # =================================================================
    rsync -aAXHx --sparse \
        --info=progress2 \
        --no-inc-recursive \
        --exclude=/proc/* \
        --exclude=/sys/* \
        --exclude=/dev/* \
        --exclude=/run/* \
        --exclude=/tmp/* \
        --exclude=/mnt/* \
        --exclude=/media/* \
        --exclude=/lost+found \
        --exclude=/boot/efi/* \
        --exclude=/target \
        --exclude=/target/* \
        --exclude=/swapfile \
        --exclude=/var/swap/* \
        / "$TARGET/" \
        2>/dev/null \
        > "$_RSYNC_FIFO" &

    _RSYNC_PID=$!

    # =================================================================
    # GAUGE
    # =================================================================
    _rsync_gauge "$(t install)" "$total_files" < "$_RSYNC_FIFO"

    # =================================================================
    # ESPERAR RSYNC REAL
    # =================================================================
    wait "$_RSYNC_PID" || _RSYNC_RC=$?

    rm -f "$_RSYNC_FIFO"

    if [[ $_RSYNC_RC -ne 0 ]]; then
        msg "Error: Falló la copia del sistema (rsync rc=$_RSYNC_RC)."
        cleanup
        exit 1
    fi

    # =================================================================
    # RECREAR DIRECTORIOS EXCLUIDOS
    # =================================================================
    mkdir -p "$TARGET"/{proc,sys,dev,run,tmp,mnt,media,boot/efi}
    chmod 1777 "$TARGET/tmp"

    # =================================================================
    # LIMPIAR MACHINE-ID (evita clones idénticos)
    # =================================================================
    rm -f "$TARGET/etc/machine-id"
    touch "$TARGET/etc/machine-id"

    rm -f "$TARGET/var/lib/dbus/machine-id"
    ln -sf /etc/machine-id "$TARGET/var/lib/dbus/machine-id"

    # =================================================================
    # UUID + FILESYSTEM ROOT
    # =================================================================
    local ROOT_UUID
    local ROOT_FS

    ROOT_UUID=$(blkid -s UUID -o value "$ROOT")
    ROOT_FS=$(blkid -s TYPE -o value "$ROOT")

    [[ -z "$ROOT_UUID" ]] && {
        msg "Error: No se pudo obtener UUID de ROOT"
        cleanup
        exit 1
    }

    [[ -z "$ROOT_FS" ]] && {
        msg "Error: No se pudo detectar filesystem de ROOT"
        cleanup
        exit 1
    }

    # =================================================================
    # FSTAB
    # =================================================================
    if [[ -d /sys/firmware/efi && -n "${EFI:-}" ]]; then

        local EFI_UUID

        EFI_UUID=$(blkid -s UUID -o value "$EFI")

        [[ -z "$EFI_UUID" ]] && {
            msg "Error: No se pudo obtener UUID de EFI"
            cleanup
            exit 1
        }

        cat > "$TARGET/etc/fstab" <<EOF
# PimersusOS fstab — generado por instalador
UUID=$ROOT_UUID /         $ROOT_FS  noatime,errors=remount-ro  0 1
UUID=$EFI_UUID  /boot/efi vfat      umask=0077                 0 2
tmpfs           /tmp      tmpfs     defaults,nosuid,nodev      0 0
EOF

    else

        cat > "$TARGET/etc/fstab" <<EOF
# PimersusOS fstab — generado por instalador
UUID=$ROOT_UUID /         $ROOT_FS  noatime,errors=remount-ro  0 1
tmpfs           /tmp      tmpfs     defaults,nosuid,nodev      0 0
EOF
    fi

    # =================================================================
    # CREAR SWAPFILE SI SE DEFINIÓ
    # =================================================================
    if [[ -n "${SWAP_MB:-}" && "$SWAP_MB" -gt 0 ]]; then

        rm -f "$TARGET/swapfile"

        fallocate -l "${SWAP_MB}M" "$TARGET/swapfile" 2>/dev/null || \
            dd if=/dev/zero of="$TARGET/swapfile" bs=1M count="$SWAP_MB" status=none

        chmod 600 "$TARGET/swapfile"
        mkswap "$TARGET/swapfile" >/dev/null 2>&1

        echo "/swapfile none swap sw 0 0" >> "$TARGET/etc/fstab"
    fi

    sync
}

# =================================================================
# RSYNC GAUGE
# =================================================================
_rsync_gauge(){

    local title="$1"
    local total_files="$2"

    {
        local pct=0
        local last_pct=-1

        local byte_pct
        local file_pct

        local done_files
        local all_files

        while IFS= read -r line; do

            # =========================================================
            # PORCENTAJE POR BYTES
            # =========================================================
            byte_pct=$(
                printf '%s' "$line" |
                grep -oE '[[:space:]][0-9]{1,3}%' |
                grep -oE '[0-9]+' |
                tail -1 || true
            )

            # =========================================================
            # PROGRESO POR ARCHIVOS
            # =========================================================
            file_pct=""

            if [[ "$line" =~ to-chk=([0-9]+)/([0-9]+) ]]; then

                done_files=$(( ${BASH_REMATCH[2]} - ${BASH_REMATCH[1]} ))
                all_files="${BASH_REMATCH[2]}"

                if [[ "$all_files" -gt 0 ]]; then
                    file_pct=$(( done_files * 100 / all_files ))
                fi
            fi

            # =========================================================
            # USAR EL MAYOR
            # =========================================================
            pct="${byte_pct:-0}"

            if [[ -n "${file_pct:-}" && "$file_pct" -gt "$pct" ]]; then
                pct="$file_pct"
            fi

            (( pct > 99 )) && pct=99
            (( pct < 0  )) && pct=0

            if [[ "$pct" -ne "$last_pct" ]]; then
                echo "$pct"
                last_pct="$pct"
            fi
        done

        echo 100

    } | dialog --gauge "$title" 7 60 0 \
        <"$TTY" >"$TTY" 2>"$TTY"
}