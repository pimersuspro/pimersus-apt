#!/bin/bash

# --- DETECTAR CARPETA DE DESCARGAS DE FORMA UNIVERSAL ---

# 1. Primero intentar con xdg-user-dir (estándar Freedesktop)
if command -v xdg-user-dir >/dev/null 2>&1; then
    DOWNLOADS_DIR=$(xdg-user-dir DOWNLOAD)
fi

# 2. Si falla, buscar carpetas comunes en muchos idiomas
if [ -z "$DOWNLOADS_DIR" ] || [ ! -d "$DOWNLOADS_DIR" ]; then
    for candidate in \
        "Descargas" "Downloads" "Herunterladen" \
        "Téléchargements" "Baixades" "Scaricati" \
        "Descărcări" "Transferências" "Pobrane" \
        "Hipak" "Λήψεις" "Скачивания"
    do
        if [ -d "$HOME/$candidate" ]; then
            DOWNLOADS_DIR="$HOME/$candidate"
            break
        fi
    done
fi

# 3. Si aun así no existe, usar fallback simple
if [ -z "$DOWNLOADS_DIR" ] || [ ! -d "$DOWNLOADS_DIR" ]; then
    DOWNLOADS_DIR="$HOME/Downloads"
fi

# Ruta del escáner
SCANNER_SCRIPT="/usr/bin/primersus-av-scan"

echo "🌍 Monitoreando carpeta de descargas: $DOWNLOADS_DIR"

# --- MONITOREO REAL-TIME SIN BLOQUEOS ---
inotifywait -m -e close_write,moved_to --format '%w%f' "$DOWNLOADS_DIR" | while read FILE_PATH
do
    echo "$(date '+%H:%M:%S') Detectado archivo: $FILE_PATH"
    "$SCANNER_SCRIPT" "$FILE_PATH" &
done
